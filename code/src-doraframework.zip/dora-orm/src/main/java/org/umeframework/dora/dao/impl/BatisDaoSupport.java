package org.umeframework.dora.dao.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.umeframework.dora.dao.DaoHelper;
import org.umeframework.dora.log.Logger;
import org.umeframework.dora.service.TableEntity;
import org.umeframework.dora.util.StringUtil;

/**
 * BatisDaoSupport
 *
 * @author Yue MA
 *
 */
public abstract class BatisDaoSupport extends SqlSessionDaoSupport {
    /**
     * theDivision key when use for Map
     */
    private String divisionKey = "theDivision";
    /**
     * Dao Helper
     */
    private DaoHelper daoHelper;
    /**
     * Logger
     */
	@Resource(name="logger")
    private Logger logger;

    /**
     * @param queryParam
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    protected void setupDivisionParam(
            Object queryParam) {
        String division = null; 
        if (daoHelper != null) {
            division = daoHelper.getTheDivision(queryParam);
        }
        if (!StringUtil.isEmpty(division)) {
            if (queryParam instanceof TableEntity) {
                ((TableEntity) queryParam).setTheDivision(division);
            } else if (queryParam instanceof Map) {
                ((Map) queryParam).put(divisionKey, division);
            }
        }
    }

    /**
     * @return the daoHelper
     */
    public DaoHelper getDaoHelper() {
        return daoHelper;
    }

    /**
     * @param daoHelper the daoHelper to set
     */
    public void setDaoHelper(
            DaoHelper daoHelper) {
        this.daoHelper = daoHelper;
    }


    /**
     * @return the logger
     */
    public Logger getLogger() {
        return logger;
    }


    /**
     * @param logger the logger to set
     */
    public void setLogger(
            Logger logger) {
        this.logger = logger;
    }

	/**
	 * @return the divisionKey
	 */
	public String getDivisionKey() {
		return divisionKey;
	}

	/**
	 * @param divisionKey the divisionKey to set
	 */
	public void setDivisionKey(String divisionKey) {
		this.divisionKey = divisionKey;
	}
}
