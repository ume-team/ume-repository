package org.umeframework.dora.appconfig;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;
import org.umeframework.dora.service.interceptor.impl.DefaultInterceptorChain;

/**
 * Intercept chain configuration.<br>
 * 
 * @author Yue Ma
 */
@Configuration
public class ServiceInterceptChainConfiguration {
	/**
	 * Authentication intercept instance
	 */
	@Resource(name = "serviceContextInterceptor")
	private Interceptor serviceContextInterceptor;
	/**
	 * Authentication intercept instance
	 */
	@Resource(name = "serviceAuthenticateInterceptor")
	private Interceptor serviceAuthenticateInterceptor;
	/**
	 * Service input intercept
	 */
	@Resource(name = "serviceInputInterceptor")
	private Interceptor serviceInputInterceptor;
	/**
	 * Service output intercept
	 */
	@Resource(name = "serviceOutputInterceptor")
	private Interceptor serviceOutputInterceptor;
	/**
	 * Service executing intercept
	 */
	@Resource(name = "serviceInterceptor")
	private Interceptor serviceInterceptor;
	/**
	 * Transaction service executing intercept
	 */
	@Resource(name = "transactionalServiceInterceptor")
	private Interceptor transactionalServiceInterceptor;

	/**
	 * defaultInterceptorChain.<br>
	 * named "sys".<br>
	 * 
	 * @return
	 */
	@Bean(name = "sys")
	@Scope("prototype")
	public InterceptorChain defaultInterceptorChain() {
		DefaultInterceptorChain instance = new DefaultInterceptorChain();
		List<Interceptor> interceptorList = new ArrayList<Interceptor>();
		interceptorList.add(serviceContextInterceptor);
		interceptorList.add(serviceAuthenticateInterceptor);
		interceptorList.add(serviceInputInterceptor);
		interceptorList.add(transactionalServiceInterceptor);
		interceptorList.add(serviceOutputInterceptor);
		instance.setInterceptorList(interceptorList);
		return instance;
	}
}
