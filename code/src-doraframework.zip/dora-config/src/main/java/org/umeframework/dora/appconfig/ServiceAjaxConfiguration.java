package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.ajax.AjaxParser;
import org.umeframework.dora.ajax.AjaxRender;

/**
 * Json perse/render configuration.<br>
 * 
 * @author Yue Ma
 */
@Configuration
public class ServiceAjaxConfiguration {
	/**
	 * ajaxParser
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "ajaxParser")
	public AjaxParser<String> ajaxParser() {
		return new org.umeframework.dora.ajax.impl.JSONParserImpl();
	}

	/**
	 * ajaxRender
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "ajaxRender")
	public AjaxRender<String> ajaxRender() {
		return new org.umeframework.dora.ajax.impl.UnicodeJSONRenderImpl();
	}
}
