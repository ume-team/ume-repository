package org.umeframework.dora.appconfig;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbcp.BasicDataSourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.connection.JdbcDataSourceManager;

/**
 * Data source configuration.<br>
 * 
 * @author Yue Ma
 */
@Configuration
public class DataSourceConfiguration {

	/**
	 * dataSource
	 * 
	 * @param driverClass
	 * @param url
	 * @param username
	 * @param password
	 * @param minIdle
	 * @param maxIdle
	 * @param maxActive
	 * @param initialSize
	 * @param maxWait
	 * @return
	 * @throws Exception
	 */
	@Scope("singleton")
	@Bean(name = "dataSource")
	public DataSource dataSource(@Autowired @Qualifier("systemProperties") SystemPropertyConfiguration systemProperties) throws Exception {

		Properties dsProp = new Properties();
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.url.toString(), systemProperties.getJdbcUrl());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.driverClassName.toString(), systemProperties.getJdbcDriverClass());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.username.toString(), systemProperties.getJdbcUsername());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.password.toString(), systemProperties.getJdbcPassword());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.initialSize.toString(), systemProperties.getJdbcInitialSize());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.maxActive.toString(), systemProperties.getJdbcMaxActive());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.maxIdle.toString(), systemProperties.getJdbcMaxIdle());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.minIdle.toString(), systemProperties.getJdbcMinIdle());
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.maxWait.toString(), systemProperties.getJdbcMaxWait());
		String autoCommit = systemProperties.getJdbcDefaultAutoCommit();
		autoCommit = autoCommit != null && autoCommit.trim().toLowerCase().equals("true") ? "true" : "false";
		dsProp.setProperty(JdbcDataSourceManager.DataSourceProperty.defaultAutoCommit.toString(), autoCommit);

		DataSource dataSource = (BasicDataSource) BasicDataSourceFactory.createDataSource(dsProp);
		return dataSource;
	}

}
