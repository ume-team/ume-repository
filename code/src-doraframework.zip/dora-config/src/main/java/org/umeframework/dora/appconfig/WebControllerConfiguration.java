package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.umeframework.dora.service.controller.CommonMessageReceiveController;
import org.umeframework.dora.service.controller.CommonRestController;

/**
 * Default restful controller configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
@ComponentScan(basePackageClasses={CommonRestController.class, CommonMessageReceiveController.class})
public class WebControllerConfiguration {

}
