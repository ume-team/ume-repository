package org.umeframework.dora.appconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.exception.SystemException;
import org.umeframework.dora.message.MessageProperties;

/**
 * Message configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class MessageConfiguration {
	/**
	 * messageProperties
	 * 
	 * @param location
	 * @return
	 * @throws SystemException
	 */
	//@Bean(name = "messageProperties", initMethod = "init")
	@Scope("singleton")
	@Bean(name = "messageProperties") 
	public MessageProperties messageProperties(@Autowired @Qualifier("systemProperties") SystemPropertyConfiguration systemProperties) throws Exception {
		return new org.umeframework.dora.message.impl.MessagePropertiesImpl(systemProperties.getMessagePropertiesLocation());
	}
}
