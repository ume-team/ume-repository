package org.umeframework.dora.appconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.property.ConfigProperties;
import org.umeframework.dora.property.impl.ConfigPropertiesImpl;
import org.umeframework.dora.service.mapping.ServiceMapping;
import org.umeframework.dora.service.mapping.impl.ServiceMappingImpl;

/**
 * Service mapping configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class ServiceMappingConfiguration {

	/**
	 * serviceMappingConfigProperties
	 * 
	 * @param location
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceMappingConfigProperties", initMethod = "init")
	public ConfigProperties serviceMappingConfigProperties(@Autowired @Qualifier("systemProperties") SystemPropertyConfiguration systemProperties) {
		ConfigPropertiesImpl instance = new ConfigPropertiesImpl(systemProperties.getServiceMappingLocation());
		return instance;
	}

	/**
	 * serviceMapping
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceMapping", initMethod = "init")
	public ServiceMapping serviceManager() {
		ServiceMappingImpl instance = new ServiceMappingImpl();
		return instance;
	}
}
