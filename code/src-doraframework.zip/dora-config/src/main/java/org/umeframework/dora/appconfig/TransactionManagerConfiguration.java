package org.umeframework.dora.appconfig;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.log.Logger;
import org.umeframework.dora.transaction.TransactionManager;
import org.umeframework.dora.transaction.impl.TransactionManagerImpl;

/**
 * Transaction configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class TransactionManagerConfiguration {
	/**
	 * dataSource
	 */
	@Qualifier("dataSource")
	@Autowired(required = false)
	private DataSource dataSource;
	/**
	 * logger
	 */
	@Qualifier("logger")
	@Autowired(required = true)
	private Logger logger;

	/**
	 * transactionManager
	 * 
	 * @return
	 * @throws Exception
	 */
	@Scope("singleton")
	@Bean(name = "transactionManager")
	public TransactionManager transactionManager() throws Exception {
		if (dataSource == null) {
			this.logger.warn("TransactionManager instance was inject as null because no found available dataSource.");
			return null;
		}
		
		TransactionManagerImpl instance = new TransactionManagerImpl();
		org.springframework.jdbc.datasource.DataSourceTransactionManager ptx = new org.springframework.jdbc.datasource.DataSourceTransactionManager();
		ptx.setDataSource(dataSource);
		instance.setPlatformTransactionManager(ptx);
		return instance;
	}


}
