package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.connection.JdbcDataSourceManager;
import org.umeframework.dora.connection.impl.JdbcDataSourceManagerImpl;

/**
 * Data source configuration.<br>
 * 
 * @author Yue Ma
 */
@Configuration
public class JdbcDataSourceManagerConfiguration {
	/**
	 * jdbcDataSourceManager
	 * 
	 * @return
	 * @throws Exception
	 */
	@Scope("singleton")
	@Bean(name = "jdbcDataSourceManager")
	public JdbcDataSourceManager jdbcDataSourceManager() throws Exception {
		JdbcDataSourceManagerImpl instance = new JdbcDataSourceManagerImpl();
		return instance;
	}
}
