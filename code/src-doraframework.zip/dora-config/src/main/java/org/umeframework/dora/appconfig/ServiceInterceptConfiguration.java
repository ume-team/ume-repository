package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.impl.ServiceAuthenticateInterceptor;
import org.umeframework.dora.service.interceptor.impl.ServiceContextInterceptor;
import org.umeframework.dora.service.interceptor.impl.ServiceInputInterceptor;
import org.umeframework.dora.service.interceptor.impl.ServiceInterceptor;
import org.umeframework.dora.service.interceptor.impl.ServiceOutputInterceptor;
import org.umeframework.dora.service.interceptor.impl.TransactionalServiceInterceptor;

/**
 * Intercept configuration.<br>
 * 
 * @author Yue Ma
 */
@Configuration
public class ServiceInterceptConfiguration {
	/**
	 * serviceContextInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceContextInterceptor")
	public Interceptor serviceContextInterceptor() {
		ServiceContextInterceptor instance = new ServiceContextInterceptor();
		return instance;
	}

	/**
	 * serviceAuthenticateInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceAuthenticateInterceptor")
	public Interceptor serviceAuthenticateInterceptor() {
		ServiceAuthenticateInterceptor instance = new ServiceAuthenticateInterceptor();
		instance.setTokenExpire(1024000);
		instance.setEnableTokenClient(true);
		instance.setEnableTokenSession(true);
		return instance;
	}

	/**
	 * serviceInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceInterceptor")
	public Interceptor serviceInterceptor() {
		ServiceInterceptor instance = new ServiceInterceptor();
		return instance;
	}
	
	/**
	 * transactionalServiceInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "transactionalServiceInterceptor")
	public Interceptor transactionalServiceInterceptor() {
		ServiceInterceptor instance = new TransactionalServiceInterceptor();
		return instance;
	}

	/**
	 * serviceInputInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceInputInterceptor")
	public Interceptor serviceInputInterceptor() {
		ServiceInputInterceptor instance = new ServiceInputInterceptor();
		return instance;
	}

	/**
	 * serviceOutputInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceOutputInterceptor")
	public Interceptor serviceOutputInterceptor() {
		ServiceOutputInterceptor instance = new ServiceOutputInterceptor();
		return instance;
	}


}
