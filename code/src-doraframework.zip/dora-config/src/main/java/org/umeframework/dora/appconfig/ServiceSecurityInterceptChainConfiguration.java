package org.umeframework.dora.appconfig;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.security.impl.SecurityHelper;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;
import org.umeframework.dora.service.interceptor.impl.DefaultInterceptorChain;
import org.umeframework.dora.service.interceptor.impl.ServiceSecurityInputInterceptor;
import org.umeframework.dora.service.interceptor.impl.ServiceSecurityOutputInterceptor;

/**
 * Security configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class ServiceSecurityInterceptChainConfiguration {
	/**
	 * Authentication intercept instance
	 */
	@Resource(name = "serviceContextInterceptor")
	private Interceptor serviceContextInterceptor;
	/**
	 * Authentication intercept instance
	 */
	@Resource(name = "serviceAuthenticateInterceptor")
	private Interceptor serviceAuthenticateInterceptor;
	/**
	 * Service executing intercept
	 */
	@Resource(name = "serviceInterceptor")
	private Interceptor serviceInterceptor;
	/**
	 * Transaction service executing intercept
	 */
	@Resource(name = "transactionalServiceInterceptor")
	private Interceptor transactionalServiceInterceptor;

	/**
	 * securityHelper
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "securityHelper")
	public SecurityHelper securityHelper() {
		SecurityHelper instance = new SecurityHelper();
		instance.setSecretKey("a4ba45ae9f32885c");
		return instance;
	}

	/**
	 * serviceSecurityInputInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceSecurityInputInterceptor")
	public Interceptor serviceSecurityInputInterceptor() {
		ServiceSecurityInputInterceptor instance = new ServiceSecurityInputInterceptor();
		instance.setDecryptor(securityHelper());
		return instance;
	}

	/**
	 * serviceSecurityOutputInterceptor
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "serviceSecurityOutputInterceptor")
	public Interceptor serviceSecurityOutputInterceptor() {
		ServiceSecurityOutputInterceptor instance = new ServiceSecurityOutputInterceptor();
		instance.setEncryptor(securityHelper());
		return instance;
	}

	/**
	 * securityInterceptorChain .<br>
	 * named "syss".<br>
	 *
	 * @return
	 */
	@Scope("prototype")
	@Bean(name = "syss")
	public InterceptorChain securityInterceptorChain() {
		DefaultInterceptorChain instance = new DefaultInterceptorChain();
		List<Interceptor> interceptorList = new ArrayList<Interceptor>();
		interceptorList.add(serviceContextInterceptor);
		interceptorList.add(serviceAuthenticateInterceptor);
		interceptorList.add(serviceSecurityInputInterceptor());
		interceptorList.add(transactionalServiceInterceptor);
		interceptorList.add(serviceSecurityOutputInterceptor());
		instance.setInterceptorList(interceptorList);
		return instance;
	}
}
