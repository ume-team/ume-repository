package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.cache.CacheManager;
import org.umeframework.dora.cache.impl.TempMemoryCachedImpl;

/**
 * Cache Manager Configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class CacheManagerConfiguration {
	/**
	 * cacheManager
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "cacheManager", initMethod = "init", destroyMethod = "shutdown")
	public CacheManager cacheManager() {
		TempMemoryCachedImpl instance = new TempMemoryCachedImpl(0);
		return instance;
	}

}
