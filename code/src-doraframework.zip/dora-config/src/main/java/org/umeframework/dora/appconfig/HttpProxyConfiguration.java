package org.umeframework.dora.appconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.http.HttpProxy;
import org.umeframework.dora.http.RemoteServiceProxy;
import org.umeframework.dora.http.impl.HttpProxyImpl;
import org.umeframework.dora.http.impl.RemoteServiceProxyImpl;

/**
 * HTTP proxy and remote service invoke configuration.<br>
 * 
 * @author Yue Ma
 */
@Configuration
public class HttpProxyConfiguration {
	/**
	 * httpProxy
	 *
	 * @return
	 * @throws Exception
	 */
	@Scope("singleton")
	@Bean(name = "httpProxy")
	public HttpProxy httpProxy() throws Exception {
		HttpProxyImpl instance = new HttpProxyImpl();
		instance.setAppContentType("application/json");
		instance.setEntityContentType("text/json");
		instance.setEntityCharset("UTF-8");
		instance.setParamCharset("UTF-8");
		instance.setUseSSL(false);
		return instance;
	}
	
    /**
     * remoteServiceProxy
     * 
     * @param httpProxy
     * @return
     * @throws Exception
     */
	@Scope("singleton")
    @Bean(name = "remoteServiceProxy")
    public RemoteServiceProxy remoteServiceProxy(@Autowired @Qualifier("httpProxy") HttpProxy httpProxy) throws Exception {
        RemoteServiceProxy instance = new RemoteServiceProxyImpl(httpProxy);
        return instance;
    }
	
}
