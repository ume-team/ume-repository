package org.umeframework.dora.appconfig;

import java.io.IOException;
import java.io.Serializable;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;

/**
 * SystemProperties
 * 
 * @author Yue Ma
 */
@Configuration
@PropertySource(value = { "classpath:application.properties", "classpath:config.properties" }, ignoreResourceNotFound = true)
public class SystemPropertyConfiguration implements Serializable {
	// SystemPropertyConfiguration define
	@Scope("singleton")
	@Bean(name = "systemProperties")
	public SystemPropertyConfiguration systemProperties() throws IOException {
		SystemPropertyConfiguration instance = new SystemPropertyConfiguration();
		return instance;
	}

	// Environment instance
	@Resource
	private Environment environment;

	// get value
	protected String get(String key) {
		String value = environment.getProperty(key);
		if (value == null && key.startsWith("ume.")) {
			key = key.substring(4);
			value = environment.getProperty(key);
		}
		return value;
	}

	// @return the messagePropertiesLocation
	public String getMessagePropertiesLocation() {
		return get("ume.messageProperties.location");
	}

	// @return the serviceMappingLocation
	public String getServiceMappingLocation() {
		return get("ume.serviceMapping.location");
	}

	// @return the sqlMapConfigLocation
	public String getSqlMapConfigLocation() {
		return get("ume.sqlMapConfig.location");
	}

	// JDBC properties configuration begin
	// @return the jdbcDriverClass
	public String getJdbcDriverClass() {
		return get("ume.jdbc.driverClassName");
	}

	// @return the jdbcUrl
	public String getJdbcUrl() {
		return get("ume.jdbc.url");
	}

	// @return the jdbcUsername
	public String getJdbcUsername() {
		return get("ume.jdbc.username");
	}

	// @return the jdbcPassword
	public String getJdbcPassword() {
		return get("ume.jdbc.password");
	}

	// @return the jdbcDefaultAutoCommit
	public String getJdbcDefaultAutoCommit() {
		return get("ume.jdbc.defaultAutoCommit");
	}

	// @return the jdbcInitialSize
	public String getJdbcInitialSize() {
		return get("ume.jdbc.initialSize");
	}

	// @return the jdbcMinIdle
	public String getJdbcMinIdle() {
		return get("ume.jdbc.minIdle");
	}

	// @return the jdbcMaxIdle
	public String getJdbcMaxIdle() {
		return get("ume.jdbc.maxIdle");
	}

	// @return the jdbcMaxActive
	public String getJdbcMaxActive() {
		return get("ume.jdbc.maxActive");
	}

	// @return the jdbcMaxWait
	public String getJdbcMaxWait() {
		return get("ume.jdbc.maxWait");
	}
	// JDBC properties configuration end

	// serialVersionUID
	private static final long serialVersionUID = -7891532311302380076L;

}
