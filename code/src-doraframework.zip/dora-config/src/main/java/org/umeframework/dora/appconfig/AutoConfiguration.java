package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * Default configuration for DoraFramework.<br>
 * 
 * @author Yue Ma
 */
@Configuration
@Import({
          SystemPropertyConfiguration.class,
          BeanFactoryConfiguration.class,
          CacheManagerConfiguration.class,
          DaoConfiguration.class,
          DataSourceConfiguration.class,
          ExceptionHandlerConfiguration.class,
          HttpProxyConfiguration.class,
          ServiceInterceptConfiguration.class,
          ServiceInterceptChainConfiguration.class,
          JdbcDataSourceManagerConfiguration.class,
          LogConfiguration.class,
          MessageConfiguration.class,
          ServiceSecurityInterceptChainConfiguration.class,
          ServiceAjaxConfiguration.class,
          ServiceMappingConfiguration.class,
          TransactionManagerConfiguration.class,
          LoginServiceConfiguration.class,
          WebControllerConfiguration.class })
public class AutoConfiguration {
	// enable all configurations by default

}
