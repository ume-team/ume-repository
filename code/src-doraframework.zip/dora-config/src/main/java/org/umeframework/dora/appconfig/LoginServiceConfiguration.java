package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.service.user.UserLoginService;
import org.umeframework.dora.service.user.impl.UserLoginServiceImpl;

/**
 * Default login service configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class LoginServiceConfiguration {

	/**
	 * userLoginService
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "userLoginService")
	public UserLoginService userLoginService() {
		UserLoginServiceImpl instance = new UserLoginServiceImpl();
		instance.setSingleLogin(false);
		return instance;
	}


}
