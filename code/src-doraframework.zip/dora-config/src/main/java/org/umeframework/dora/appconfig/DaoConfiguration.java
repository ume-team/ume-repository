package org.umeframework.dora.appconfig;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.io.DefaultResourceLoader;
import org.umeframework.dora.dao.RdbDao;
import org.umeframework.dora.dao.impl.BatisDaoImpl;
import org.umeframework.dora.dao.mybatis.ex.StatementHandlerInterceptor;
import org.umeframework.dora.log.Logger;

/**
 * Dao configuration.<br>
 *
 *
 * @author Yue Ma
 */
@Configuration
public class DaoConfiguration {
	/**
	 * systemProperties
	 */
	@Resource(name = "systemProperties")
	private SystemPropertyConfiguration systemProperties;
	
	/**
	 * dataSource
	 */
	@Qualifier("dataSource")
	@Autowired(required = false)
	private DataSource dataSource;

	/**
	 * logger
	 */
	@Qualifier("logger")
	@Autowired(required = true)
	private Logger logger;

	/**
	 * RdbDao
	 * 
	 * @return
	 * @throws Exception
	 */
	@Scope("singleton")
	@Bean(name = "dao")
	public RdbDao dao() throws Exception {
		if (dataSource == null) {
			this.logger.warn("RdbDao instance was inject as null because no found available dataSource.");
			return null;
		}
		
		RdbDao dao = new BatisDaoImpl();
		((SqlSessionDaoSupport) dao).setSqlSessionFactory(createSqlSessionFactory(dataSource, logger));
		return dao;
	}

	/**
	 * createSqlSessionFactory
	 * 
	 * @param dataSource
	 * @return
	 * @throws Exception
	 */
	protected SqlSessionFactory createSqlSessionFactory(DataSource dataSource, Logger logger) throws Exception {
		SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
		sessionFactoryBean.setDataSource(dataSource);
		sessionFactoryBean.setConfigLocation(new DefaultResourceLoader().getResource(systemProperties.getSqlMapConfigLocation()));
		StatementHandlerInterceptor statementHandlerInterceptor = new StatementHandlerInterceptor();
		statementHandlerInterceptor.setLogger(logger);
		StatementHandlerInterceptor[] plugins = new StatementHandlerInterceptor[] { statementHandlerInterceptor };
		sessionFactoryBean.setPlugins(plugins);
		return sessionFactoryBean.getObject();
	}

}
