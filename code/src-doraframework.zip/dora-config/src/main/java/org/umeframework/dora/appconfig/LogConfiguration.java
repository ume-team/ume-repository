package org.umeframework.dora.appconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.umeframework.dora.log.Logger;

/**
 * Log configuration.<br>
 *
 * @author Yue Ma
 */
@Configuration
public class LogConfiguration {
	/**
	 * createLogger
	 * 
	 * @return
	 */
	@Scope("singleton")
	@Bean(name = "logger")
	public Logger createLogger() {
		return new org.umeframework.dora.log.impl.Log4j2Impl();
	}

}
