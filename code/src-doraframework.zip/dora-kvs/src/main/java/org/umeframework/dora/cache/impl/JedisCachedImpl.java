package org.umeframework.dora.cache.impl;

import org.umeframework.dora.cache.CacheManager;

import redis.clients.jedis.Jedis;

/**
 * Jedis cache implementation
 *
 * @author Yue MA
 */
public class JedisCachedImpl extends CachedSupport implements CacheManager {
	/**
	 * Block for synchronized thread
	 */
	private static final byte[] block = new byte[0];

	/**
	 * JedisCachedImpl
	 *
	 * @param expire
	 */
	public JedisCachedImpl(String host, int port, int expire) {
		super(expire);
		this.host = host;
		this.port = port;
	}

	/**
	 * cached server host address
	 */
	private String host;
	/**
	 * cached server port number
	 */
	private int port;

	/**
	 * Jedis instance
	 */
	private Jedis jedis;

	/**
	 * Initialized Jedis instance
	 */
	@Override
	synchronized public void init() {
		jedis = new Jedis(host, port, getExpire());
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.umeframework.dora.cache.CacheManager#set(java.lang.String, int,
	 * java.lang.Object)
	 */
	@Override
	public void doSet(String key, int expire, Object value) {
		synchronized (block) {
			byte[] bkey = key.getBytes();
			byte[] bvalue = serialize(value);
			if (jedis.exists(key)) {
				// Only set the key if it already exist
				jedis.set(bkey, bvalue, "XX".getBytes(), "PX".getBytes(), expire);
			} else {
				// Only set the key if it does not already exist
				jedis.set(bkey, bvalue, "NX".getBytes(), "PX".getBytes(), expire);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.umeframework.dora.cache.CacheManager#get(java.lang.String)
	 */
	@Override
	public Object doGet(String key) {
		byte[] kbytes = key.getBytes();
		byte[] vbytes = jedis.get(kbytes);
		Object obj = unserialize(vbytes);
		return obj;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.umeframework.dora.cache.CacheManager#remove(java.lang.String)
	 */
	@Override
	public void doRemove(String key) {
		synchronized (block) {
			byte[] kbytes = key.getBytes();
			jedis.del(kbytes);
		}
	}

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host
	 *            the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @param port
	 *            the port to set
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * @return the jedis
	 */
	public Jedis getJedis() {
		return jedis;
	}

	/**
	 * @param jedis
	 *            the jedis to set
	 */
	public void setJedis(Jedis jedis) {
		this.jedis = jedis;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.cache.CacheManager#shutdown()
	 */
	@Override
	synchronized public void shutdown() {
		jedis.close();
	}
}
