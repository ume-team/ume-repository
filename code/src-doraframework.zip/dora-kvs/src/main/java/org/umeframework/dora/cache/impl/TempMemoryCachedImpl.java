package org.umeframework.dora.cache.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.umeframework.dora.cache.CacheManager;

/**
 * Temp memory cache implementation
 *
 * @author Yue MA
 */
public class TempMemoryCachedImpl extends CachedSupport implements CacheManager {
	
	/**
	 * Cache instance
	 */
	private Map<String, Object> container;
	
	/**
	 * host (not use currently)
	 */
	private String host;
	/**
	 * port (not use currently)
	 */
	private String port;
	/**
	 * user (not use currently)
	 */
	private String user;
	/**
	 * password (not use currently)
	 */
	private String password;

    /**
     * TempMemoryCachedImpl
     */
    public TempMemoryCachedImpl() {
        super(0);
    }

    /**
     * TempMemoryCachedImpl
     *
     * @param expire
     */
    public TempMemoryCachedImpl(
            int expire) {
        super(expire);
    }
    
    /**
     * TempMemoryCachedImpl
     *
     * @param host
     * @param port
     * @param user
     * @param password
     * @param expire
     */
    public TempMemoryCachedImpl(
    		String host,
    		String port,
    		String user,
    		String password,
            int expire) {
        super(expire);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.cache.CacheManager#set(java.lang.String, int,
     * java.lang.Object)
     */
    @Override
    synchronized public void doSet(
            String key,
            int expire,
            Object value) {
    	container.put(key, value);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.cache.CacheManager#get(java.lang.String)
     */
    @Override
    public Object doGet(
            String key) {
        return container.get(key);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.cache.CacheManager#remove(java.lang.String)
     */
    @Override
    synchronized public void doRemove(
            String key) {
        container.remove(key);
    }

    /* (non-Javadoc)
     * @see org.umeframework.dora.cache.CacheManager#init()
     */
    @Override
    synchronized public void init() {
    	if (container != null) {
    		container.clear();
    	}
    	container = new ConcurrentHashMap<String, Object>();
        getLogger().info("Temp memory cached instance start.");
    }

    /* (non-Javadoc)
     * @see org.umeframework.dora.cache.CacheManager#shutdown()
     */
    @Override
    synchronized public void shutdown() {
    	if (container != null) {
    		container.clear();
    		getLogger().info("Temp memory cached instance shutdown.");
    	}
    }

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(
			String host) {
		this.host = host;
	}

	/**
	 * @return the port
	 */
	public String getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(
			String port) {
		this.port = port;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(
			String user) {
		this.user = user;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(
			String password) {
		this.password = password;
	}
}
