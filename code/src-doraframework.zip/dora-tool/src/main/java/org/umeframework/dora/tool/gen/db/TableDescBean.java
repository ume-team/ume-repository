package org.umeframework.dora.tool.gen.db;

import java.util.ArrayList;
import java.util.List;

/**
 * Table define infromation.<br>
 */
public class TableDescBean implements java.io.Serializable {

	/**
	 * serial version UID
	 */
	private static final long serialVersionUID = -2945682002269108154L;
	/**
     * current generate date
     */
    private String currentDate;
    /**
     * table comment in DDL define
     */
    private String tblName;
    /**
     * table identify name (ID)
     */
    private String tblId;
    /**
     * table devision code while using devision
     */
    private String tblDivision;
    /**
     * docName
     */
    private String docName;
    /**
     * auto increment columns
     */
    /**
     * all Dto fields
     */
    private List<FieldDescBean> fieldList = new ArrayList<FieldDescBean>();

    /**
     * @return the tblName
     */
    public String getTblName() {
        return tblName;
    }

    /**
     * @param tblName
     *            the tblName to set
     */
    public void setTblName(
            String tblName) {
        this.tblName = tblName;
    }

    /**
     * @return the tblId
     */
    public String getTblId() {
        return tblId;
    }

    /**
     * @param tblId
     *            the tblId to set
     */
    public void setTblId(
            String tblId) {
        this.tblId = tblId;
    }

    /**
     * @return
     */
    public String getCurrentDate() {
        return currentDate;
    }

    /**
     * @param currentDate
     */
    public void setCurrentDate(
            String currentDate) {
        this.currentDate = currentDate;
    }

    /**
     * @return the tblDivision
     */
    public String getTblDivision() {
        return tblDivision;
    }

    /**
     * @param tblDivision
     *            the tblDivision to set
     */
    public void setTblDivision(
            String tblDivision) {
        this.tblDivision = tblDivision;
    }

//	/**
//	 * @return the autoIncrementColumnList
//	 */
//	public List<String> getAutoIncrementColumnList() {
//		return autoIncrementColumnList;
//	}
//
//	/**
//	 * @param autoIncrementColumnList the autoIncrementColumnList to set
//	 */
//	public void setAutoIncrementColumnList(List<String> autoIncrementColumnList) {
//		this.autoIncrementColumnList = autoIncrementColumnList;
//	}

	/**
	 * @return the fieldList
	 */
	public List<FieldDescBean> getFieldList() {
		return fieldList;
	}

	/**
	 * @param fieldList the fieldList to set
	 */
	public void setFieldList(List<FieldDescBean> fieldList) {
		this.fieldList = fieldList;
	}

	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}

	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}

}
