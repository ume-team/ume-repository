package org.umeframework.dora.tool.gen.sql;

import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.umeframework.dora.dao.impl.JdbcDaoImpl;
import org.umeframework.dora.log.Logger;
import org.umeframework.dora.log.impl.Log4j2Impl;
import org.umeframework.dora.tool.gen.db.DataTypeUtil;
import org.umeframework.dora.tool.poi.CellWriter;
import org.umeframework.dora.tool.poi.ExcelAccessor;
import org.umeframework.dora.tool.poi.SimpleCellWriter;

/**
 * 1.根据Excel输入的Table列表信息及数据库连接信息，查询数据字典获取表定义的结构， 以此结构创建Excel的页并导出数据库中的既存数据至Excel文件。 2.根据上述模版结构编辑数据，将编辑后的数据生成可更新至数据库的SQL。
 * 
 * @author mayue
 */
public class Excel2SqlGenerator extends ExcelAccessor {
	/**
	 * 访问的Excel HSSF 对象
	 */
	private Workbook book;
	/**
	 * 访问的Excel文件名
	 */
	private String excelFile;
	/**
	 * Dao实例
	 */
	private JdbcDaoImpl dao;
	/**
	 * 数据字典查询SQL语句
	 */
	private String tableDescQueryStr = "select"
	        + " COLUMN_NAME as 'colId',"
	        + " COLUMN_COMMENT as 'colName',"
	        + " DATA_TYPE as 'dataType',"
	        + " case"
	        + " when DATA_TYPE='bigint' or DATA_TYPE='tinyint' or DATA_TYPE='smallint' or DATA_TYPE='mediumint' or DATA_TYPE='int' then NUMERIC_PRECISION+1"
	        + " when DATA_TYPE='decimal' or DATA_TYPE='double' or DATA_TYPE='float' then NUMERIC_PRECISION"
	        + " when DATA_TYPE='varchar' or DATA_TYPE='char' then CHARACTER_MAXIMUM_LENGTH"
	        + " else CHARACTER_OCTET_LENGTH"
	        + " end as 'dataLength',"
	        + " NUMERIC_PRECISION as 'dataPrecision',"
	        + " NUMERIC_SCALE as 'dataScale',"
	        + " case when COLUMN_KEY='PRI' then '1' else '0' end as 'pkFlag',"
	        + " case when IS_NULLABLE='NO' then '1' else '0' end as 'notNull',"
	        + " COLUMN_DEFAULT as 'defaultValue'"
	        + " from INFORMATION_SCHEMA.COLUMNS"
	        + " where TABLE_NAME = {varTableId} AND TABLE_SCHEMA = {varSchema};";
	/**
	 * 取得时间戳的函数名
	 */
	private String currentTimestampStr = "current_timestamp()";

	/**
	 * logger
	 */
	private Logger logger = new Log4j2Impl();

	/**
	 * 构造函数
	 * 
	 * @param excelFile
	 * @param tableDescQueryStr
	 * @throws Exception
	 */
	public Excel2SqlGenerator(String excelFile) throws Exception {
		this.excelFile = excelFile;

		book = loadExcel(new File(excelFile));
		dao = new JdbcDaoImpl();
		DataSource ds = getDataSource();
		((JdbcDaoImpl) dao).setDataSource(ds);
		((JdbcDaoImpl) dao).setLogger(logger);
	}

	/**
	 * 构造函数
	 */
	public Excel2SqlGenerator() throws Exception {
	}

	/**
	 * createTableDataDesc
	 * 
	 * @param inputPath
	 * @throws Throwable
	 */
	public void createTableDataDesc(String inputPath) throws Throwable {
		for (File file : getFiles(inputPath)) {
			Excel2SqlGenerator gen = new Excel2SqlGenerator(file.getPath());
			gen.createTableDescPages(true);
			System.out.println(file.getName() + "处理完成.");
		}
	}

	/**
	 * createTableDataSqlScript
	 * 
	 * @param inputPath
	 * @throws Throwable
	 */
	public void createTableDataSqlScript(String inputPath) throws Throwable {
		for (File file : getFiles(inputPath)) {
			Excel2SqlGenerator gen = new Excel2SqlGenerator(file.getPath());
			String currentTimestampStr = "current_timestamp()";
			gen.setCurrentTimestampStr(currentTimestampStr);
			gen.createSQLs();
			System.out.println(file.getName() + "处理完成.");
		}
	}

	/**
	 * createTableDoc
	 * 
	 * @param inputPath
	 * @throws Throwable
	 */
	public void createTableDoc(String inputPath) throws Throwable {
		for (File file : getFiles(inputPath)) {
			Excel2SqlGenerator gen = new Excel2SqlGenerator(file.getPath());
			gen.createTableDocPages();
			System.out.println(file.getName() + "处理完成.");
		}
	}

	/**
	 * @param inputPath
	 * @return
	 * @throws Exception
	 */
	protected File[] getFiles(String inputPath) throws Exception {
		File[] files = new File(inputPath).listFiles(new FileFilter() {
			@Override
			public boolean accept(File e) {
				String name = e.getName().toLowerCase();
				return name.endsWith(".xls") || name.endsWith(".xlsx");
			}
		});
		return files;
	}

	/**
	 * 创建数据Insert用的SQL语句
	 * 
	 * @throws Exception
	 */
	protected void createSQLs() throws Exception {
		String lineSeparator = System.getProperty("line.separator");
		String sqlFile = excelFile.substring(0, excelFile.lastIndexOf(".")) + ".sql";
		String charset = "UTF-8";
		OutputStreamWriter printer = null;
		try {
			printer = new OutputStreamWriter(new FileOutputStream(sqlFile), charset);
			// List<List<Object>> allSqls = new ArrayList<List<Object>>();
			for (int i = 0; i < book.getNumberOfSheets(); i++) {
				Sheet sheet = book.getSheetAt(i);
				if (sheet.getSheetName().startsWith("#")) {
					continue;
				}
				List<String> sqls = createTableInsertSQL(this.excelFile, sheet.getSheetName());

				for (String sql : sqls) {
					printer.write(sql);
					printer.write(lineSeparator);
				}
				printer.write(lineSeparator);
				printer.flush();

			}
		} finally {
			printer.close();
		}
	}

	/**
	 * 创建数据Insert用的SQL语句
	 * 
	 * @throws Exception
	 */
	protected List<String> createTableInsertSQL(String excelFile, String sheetName) throws Exception {
		List<String> sqls = new ArrayList<String>();
		Sheet sheet = book.getSheet(sheetName);

		int x = 1;
		int y = 0;
		String value = getCellValueAsString(sheet, x, y);
		while (!isEmpty(value)) {
			y++;
			value = getCellValueAsString(sheet, x, y);
		}

		int[] targetColIndexes = new int[y];
		for (int c = 0; c < targetColIndexes.length; c++) {
			targetColIndexes[c] = c;
		}

		StringBuilder sql = new StringBuilder();
		String table = sheet.getSheetName();
		sql.append("DELETE FROM " + table + " ;");
		sqls.add(sql.toString());

		List<List<Object>> rows = super.readSheetAsObjectList(new File(excelFile), sheet.getSheetName(), targetColIndexes, 0, 65535);
		List<Object> cols = rows.get(1);
		List<Object> types = rows.get(2);
		for (int rowIndex = 3; rowIndex < rows.size(); rowIndex++) {
			List<Object> datas = rows.get(rowIndex);
			sql = new StringBuilder();
			sql.append("INSERT INTO " + table + "(");
			for (int k = 0; k < cols.size(); k++) {
				if (k > 0) {
					sql.append(",");
				}
				sql.append(cols.get(k));
			}
			sql.append(") VALUES (");
			for (int k = 0; k < datas.size(); k++) {
				if (k > 0) {
					sql.append(",");
				}
				sql.append(convertInsertValue(cols.get(k).toString(), types.get(k).toString(), datas.get(k) == null ? "" : datas.get(k).toString()));
			}
			sql.append(") ;");
			sqls.add(sql.toString());
		}
		System.out.println("SQL创建成功:" + table);
		return sqls;
	}

	/**
	 * convertInsertValue
	 * 
	 * @param type
	 * @param value
	 * @return
	 */
	protected String convertInsertValue(String col, String typeStr, String value) {
		String result = null;
		typeStr = typeStr.toUpperCase();
		typeStr = typeStr.contains("(") ? typeStr.substring(0, typeStr.indexOf("(")) : typeStr;
		if (typeStr.equals("CHARACTER")
		        || typeStr.equals("CHAR")
		        || typeStr.equals("VARCHAR")
		        || typeStr.equals("VARCHAR2")
		        || typeStr.equals("LONGVARCHAR")) {
			if (isEmpty(value)) {
				result = "null";
			} else if (value.contains("'")) {
				value = value.replace("'", "\\'");
				result = "'" + value + "'";
			} else {
				result = "'" + value + "'";
			}
		} else if (typeStr.equals("TIMESTAMP") || typeStr.equals("TIME") || typeStr.equals("DATE") || typeStr.equals("DATETIME")) {
			if (col.toUpperCase().equals("UPDATE_DATETIME")) {
				result = currentTimestampStr;
			} else if (col.toUpperCase().equals("CREATE_DATETIME") && isEmpty(value)) {
				result = currentTimestampStr;
			}
		} else {
			result = value.toString();
		}
		return isEmpty(result) ? "null" : result;
	}

	/**
	 * 创建表定义的Excel页
	 * 
	 * @throws Throwable
	 */
	protected void createTableDocPages() throws Throwable {
		List<String[]> tblConfigInfo = getTblConfigInfo();
		for (String[] e : tblConfigInfo) {
			String schemaName = e[0];
			String tableName = e[1];
			Map<String, String> param = new HashMap<String, String>();
			param.put("varSchema", schemaName);
			param.put("varTableId", tableName);
			@SuppressWarnings("rawtypes")
			List<LinkedHashMap> tableDesc = dao.queryForObjectList(tableDescQueryStr, param, LinkedHashMap.class);
			tableName = tableName.length() > 30 ? tableName.substring(0, 29) : tableName;
			createTableDocPage(tableName, tableDesc);
			System.out.println("创建 " + tableName + " 的定义文档。");
		}
	}

	/**
	 * 创建表定义的Excel页
	 * 
	 * @param tableName
	 * @param tableDesc
	 */
	protected void createTableDocPage(String tableName, @SuppressWarnings("rawtypes") List<LinkedHashMap> tableDesc) {
		List<List<Object>> rows = new ArrayList<List<Object>>();
		List<Object> row1 = createList(new Object[] { "表描述", "", tableName, "", "", "", "TABLE SPACE", "", "", "", "", "", "" });
		List<Object> row2 = createList(new Object[] { "表名称", "", tableName, "", "", "", "TABLE SPACE (IDX)", "", "", "", "", "", "" });
		List<Object> row3 = createList(new Object[] { "分表设定", "", "", "", "", "", "TABLE SPACE (LOB)", "", "", "", "", "", "" });
		List<Object> row4 = createList(new Object[] { "", "", "", "", "", "", "", "", "", "", "", "", "" });
		List<Object> row5 = createList(new Object[] { "序号", "项目名", "项目ID", "数据类型", "长度", "主键", "非空", "默认值", "固定值", "最小值", "最大值", "格式", "备注" });
		rows.add(row1);
		rows.add(row2);
		rows.add(row3);
		rows.add(row4);
		rows.add(row5);

		int colIndex = 1;
		for (LinkedHashMap<?, ?> e : tableDesc) {
			Object colName = e.get("colName");
			Object colId = e.get("colId");
			String type = String.valueOf(e.get("dataType"));
			type = DataTypeUtil.getTextDescFromType(type);
			String length = "";
			if (e.get("dataPrecision") != null && e.get("dataScale") != null) {
				length = e.get("dataPrecision") + "," + e.get("dataScale");
			} else if (e.get("dataPrecision") != null) {
				length = e.get("dataPrecision").toString();
			} else if (e.get("dataLength") != null) {
				length = e.get("dataLength").toString();
			}
			String pkFlag = e.get("pkFlag").toString().equals("1") ? "○" : "";
			String notNull = e.get("notNull").toString().equals("1") ? "○" : "";

			List<Object> row = createList(new Object[] { colIndex, colName, colId, type, length, pkFlag, notNull, "", "", "", "", "", "" });
			colIndex++;
			rows.add(row);
		}

		super.createSheet(excelFile, tableName, rows, new CellWriter<Object>() {
			@SuppressWarnings("deprecation")
			@Override
			public void write(Cell cell, Object value) {
				int rowIndex = cell.getRowIndex();
				int colIndex = cell.getColumnIndex();
				new SimpleCellWriter().write(cell, value);

				CellStyle cellstyle = cell.getCellStyle();
				if (rowIndex < 5) {
					cellstyle.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);
					cellstyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				} else {
					if (colIndex == 3 || colIndex == 5 || colIndex == 6) {
						cellstyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
						cellstyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
					}
				}
				cell.setCellStyle(cellstyle);
			}
		});
	}

	/**
	 * createList
	 * 
	 * @param arr
	 * @return
	 */
	protected List<Object> createList(Object[] arr) {
		List<Object> list = new ArrayList<Object>(arr.length);
		for (Object e : arr) {
			list.add(e);
		}
		return list;
	}

	/**
	 * 导出表数据
	 * 
	 * @throws Throwable
	 */
	protected void createTableDescPages(boolean selectExistData) throws Throwable {
		List<String[]> tblConfigInfo = getTblConfigInfo();
		for (String[] e : tblConfigInfo) {
			String schemaName = e[0];
			String tableName = e[1];
			String whereCondition = e[2];
			Map<String, String> param = new HashMap<String, String>();
			param.put("varSchema", schemaName);
			param.put("varTableId", tableName);

			@SuppressWarnings("rawtypes")
			List<LinkedHashMap> tableDesc = dao.queryForObjectList(tableDescQueryStr, param, LinkedHashMap.class);

			String tableDataQueryStr = createTableDataQueryStr(tableDesc, schemaName, tableName, whereCondition);
			@SuppressWarnings("rawtypes")
			List<LinkedHashMap> tableData = dao.queryForObjectList(tableDataQueryStr, null, LinkedHashMap.class);

			tableName = tableName.length() > 30 ? tableName.substring(0, 29) : tableName;
			createTableDescPage(tableName, tableDesc, tableData);
			System.out.println("创建 "
			        + tableName
			        + " 数据模版，抽出"
			        + (tableData == null ? 0 : tableData.size())
			        + "条既存数据。"
			        + (isEmpty(whereCondition) ? "" : "抽出条件=" + whereCondition));
		}
	}

	/**
	 * 创建导出表数据的Excel页
	 * 
	 * @param tableName
	 * @param tableDesc
	 */
	protected void createTableDescPage(
	        String tableName,
	        @SuppressWarnings("rawtypes") List<LinkedHashMap> tableDesc,
	        @SuppressWarnings("rawtypes") List<LinkedHashMap> tableData) {

		List<List<Object>> rows = new ArrayList<List<Object>>();
		List<Object> row1 = new ArrayList<Object>();
		List<Object> row2 = new ArrayList<Object>();
		List<Object> row3 = new ArrayList<Object>();

		int colIndex = 0;
		for (LinkedHashMap<?, ?> e : tableDesc) {
			int pkFlag = e.get("pkFlag").toString().equals("1") ? 1 : 0;
			int notNull = e.get("notNull").toString().equals("1") ? 1 : 0;

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("value", e.get("colName"));
			map.put("rowIndex", 0);
			map.put("colIndex", colIndex);
			map.put("pkFlag", pkFlag);
			map.put("notNull", notNull);
			row1.add(map);

			map = new HashMap<String, Object>();
			map.put("value", e.get("colId"));
			map.put("rowIndex", 1);
			map.put("colIndex", colIndex);
			map.put("pkFlag", pkFlag);
			map.put("notNull", notNull);
			row2.add(map);

			String type = String.valueOf(e.get("dataType"));
			String length = "";
			if (e.get("dataPrecision") != null && e.get("dataScale") != null) {
				length = "(" + e.get("dataPrecision") + "," + e.get("dataScale") + ")";
			} else if (e.get("dataPrecision") != null) {
				length = "(" + e.get("dataPrecision") + ")";
			} else if (e.get("dataLength") != null) {
				length = "(" + e.get("dataLength") + ")";
			}
			map = new HashMap<String, Object>();
			map.put("value", type + length);
			map.put("rowIndex", 2);
			map.put("colIndex", colIndex);
			map.put("pkFlag", pkFlag);
			map.put("notNull", notNull);
			row3.add(map);

			colIndex++;
		}
		rows.add(row1);
		rows.add(row2);
		rows.add(row3);

		if (tableData != null) {
			for (LinkedHashMap<?, ?> e : tableData) {
				List<Object> row = new ArrayList<Object>();
				Iterator<?> itr = e.values().iterator();
				while (itr.hasNext()) {
					Object ee = itr.next();
					ee = ee == null ? "" : ee;
					row.add(ee);
				}
				rows.add(row);
			}
		}

		super.createSheet(excelFile, tableName, rows, new CellWriter<Object>() {
			@SuppressWarnings({ "rawtypes", "deprecation" })
			@Override
			public void write(Cell cell, Object value) {
				if (value instanceof Map) {
					Object actValue = ((Map) value).get("value");
					new SimpleCellWriter().write(cell, actValue);

					int rowIndex = (Integer) ((Map) value).get("rowIndex");
					int pkFlag = (Integer) ((Map) value).get("pkFlag");
					int notNull = (Integer) ((Map) value).get("notNull");

					CellStyle cellstyle = cell.getCellStyle();
					if (rowIndex < 3) {
						if (pkFlag == 1) {
							cellstyle.setFillForegroundColor(HSSFColor.LIGHT_ORANGE.index);
						} else if (notNull == 1) {
							cellstyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
						} else {
							cellstyle.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);
						}
						cellstyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
						cell.setCellStyle(cellstyle);

					}
				} else {
					new SimpleCellWriter().write(cell, value);
				}
			}
		});
	}

	/**
	 * 读取表名列表
	 * 
	 * @return
	 */
	protected List<String[]> getTblConfigInfo() {
		List<String[]> configs = new ArrayList<String[]>();
		Sheet sheet = book.getSheet("#TBLCONFIG");
		Coordinate coordinate = lookupDataCell(sheet, "SET SCHEMA");
		int row = coordinate.x + 1;
		int col = coordinate.y;
		String schema = getCellValueAsString(sheet, row, col);
		String table = getCellValueAsString(sheet, row, col + 1);
		String condition = getCellValueAsString(sheet, row, col + 2);
		while (!isEmpty(schema)) {
			String[] config = new String[] { schema.trim(), table.trim(), condition.trim() };
			configs.add(config);
			row++;
			schema = getCellValueAsString(sheet, row, col);
			table = getCellValueAsString(sheet, row, col + 1);
			condition = getCellValueAsString(sheet, row, col + 2);
		}
		return configs;
	}

	/**
	 * 创建表数据查询SQL语句
	 * 
	 * @param desc
	 * @param schemaName
	 * @param tableName
	 * @param whereCondition
	 * @return
	 */
	protected String createTableDataQueryStr(
	        @SuppressWarnings("rawtypes") List<LinkedHashMap> desc,
	        String schemaName,
	        String tableName,
	        String whereCondition) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT ");
		for (int i = 0; i < desc.size(); i++) {
			if (i > 0) {
				builder.append(",");
			}
			builder.append(desc.get(i).get("colId"));
		}
		builder.append(" FROM ");
		builder.append(schemaName);
		builder.append(".");
		builder.append(tableName);
		if (whereCondition != null && !whereCondition.trim().equals("")) {
			builder.append(" WHERE ");
			builder.append(whereCondition);
		}
		builder.append(" ORDER BY UPDATE_DATETIME");
		return builder.toString();
	}

	/**
	 * 取得数据库数据源
	 * 
	 * @return
	 * @throws Exception
	 */
	protected DataSource getDataSource() throws Exception {
		Sheet sheet = book.getSheet("#DBCONFIG");
		Coordinate coordinate = lookupDataCell(sheet, "DATABASE DRIVER");
		String driver = getCellValueAsString(sheet, coordinate.x, coordinate.y + 1);
		coordinate = lookupDataCell(sheet, "DATABASE URL");
		String url = getCellValueAsString(sheet, coordinate.x, coordinate.y + 1);
		coordinate = lookupDataCell(sheet, "DATABASE USER");
		String user = getCellValueAsString(sheet, coordinate.x, coordinate.y + 1);
		coordinate = lookupDataCell(sheet, "DATABASE PASSWORD");
		String password = getCellValueAsString(sheet, coordinate.x, coordinate.y + 1);

		Properties dsProp = new Properties();
		dsProp.setProperty("driverClassName", driver);
		dsProp.setProperty("url", url);
		dsProp.setProperty("username", user);
		dsProp.setProperty("password", password);

		DataSource ds = BasicDataSourceFactory.createDataSource(dsProp);
		System.out.println("连接至数据库:" + url);
		return ds;
	}

	/**
	 * @return the tableDescQueryStr
	 */
	public String getTableDescQueryStr() {
		return tableDescQueryStr;
	}

	/**
	 * @param tableDescQueryStr
	 *            the tableDescQueryStr to set
	 */
	public void setTableDescQueryStr(String tableDescQueryStr) {
		this.tableDescQueryStr = tableDescQueryStr;
	}

	/**
	 * @return the currentTimestampStr
	 */
	public String getCurrentTimestampStr() {
		return currentTimestampStr;
	}

	/**
	 * @param currentTimestampStr
	 *            the currentTimestampStr to set
	 */
	public void setCurrentTimestampStr(String currentTimestampStr) {
		this.currentTimestampStr = currentTimestampStr;
	}

}
