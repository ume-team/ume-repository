package org.umeframework.dora.tool.gen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import org.umeframework.dora.tool.gen.db.DefaultDtoBuilder;
import org.umeframework.dora.tool.gen.db.DtoBuilder;
import org.umeframework.dora.tool.gen.db.EntityDescBean;
import org.umeframework.dora.tool.gen.db.TableDescBean;
import org.umeframework.dora.tool.gen.db.DataTypeUtil.DatabaseType;

/**
 * TableGenerator
 */
public class EntityGenerator {
	// generate Dto package setting
	private String genDtoPackage;
	
	// generate file DIR setting
	private String genDirJava = "src/main/gen/";
	private String genDirResource = "src/main/gen/";
	private String genDirSqlMap = getGenDirResource() + "sql/tbl/";
	private String genDirSql = "src/main/gen/ddl/";
	
	// VM template setting
	private String templateSqlMap = "template/table-sqlmap-{PROVIDER}.vm";
	private String templateSql = "template/table-ddl-{PROVIDER}.vm";
	private String templateSqlBat = "template/table-ddlbat-{PROVIDER}.vm";
	
	// VM template setting
	private String templateDto = "template/entity-dto.vm";
	private String templateCrudInterface = "template/entity-crud-interface.vm";
	private String templateCrudImpl = "template/entity-crud-impl.vm";
	private String templateCrudWsid = "template/entity-crud-wsid.vm";

	private DtoBuilder dtoBuilder;
	// Code engine
	protected CodeGenerator cgSqlMap;
	protected CodeGenerator cgDto;
	protected CodeGenerator cgSql;
	protected CodeGenerator cgSqlBat;
	protected CodeGenerator cgCrudInterface;
	protected CodeGenerator cgCrudClass;
	protected CodeGenerator cgCrudMapping;
	
	/**
	 * Database type
	 */
	private DatabaseType database;

	/**
	 * TableGenerator
	 * 
	 * @param databaseProvider
	 * @throws IOException 
	 */
	public EntityGenerator(DatabaseType dbType) throws IOException {
		this.database = dbType;
		dtoBuilder = new DefaultDtoBuilder(this);
	}
	
	/**
	 * TableGenerator
	 * @throws IOException 
	 */
	public EntityGenerator() throws IOException {
		this(DatabaseType.MySQL);
	}
	
	/**
	 * Filter provider 
	 * 
	 * @param name
	 * @return
	 */
	protected String doFilter(String name) {
		return name.replace("{PROVIDER}", database.toString().toLowerCase());
	}

	/**
	 * prepare
	 */
	protected void prepare() {
		// Replace dynamic token string for "{PROVIDER}"
		genDirSql = doFilter(genDirSql);
		genDirSqlMap = doFilter(genDirSqlMap);
		
		templateSqlMap = doFilter(templateSqlMap);
		templateSql = doFilter(templateSql);
		templateSqlBat = doFilter(templateSqlBat);
		// Create CodeGenerator instance
		cgSqlMap = new CodeGenerator(templateSqlMap);
		cgDto = new CodeGenerator(templateDto);
		cgSql = new CodeGenerator(templateSql);
		cgSqlBat = new CodeGenerator(templateSqlBat);
		cgCrudInterface = new CodeGenerator(templateCrudInterface);
		cgCrudClass = new CodeGenerator(templateCrudImpl);
		cgCrudMapping = new CodeGenerator(templateCrudWsid);

		if (!new File(genDirJava).exists()) {
			new File(genDirJava).mkdirs();
		}
		if (!new File(genDirResource).exists()) {
			new File(genDirResource).mkdirs();
		}
		if (!new File(genDirSql).exists()) {
			new File(genDirSql).mkdirs();
		}
		if (!new File(genDirSqlMap).exists()) {
			new File(genDirSqlMap).mkdirs();
		}
	}

	/**
	 * execute
	 * 
	 * @param dtoList
	 * @throws Exception
	 */
	public void execute(Collection<TableDescBean> dtoList) throws Exception {
		execute(null, dtoList);
	}

	/**
	 * execute
	 * 
	 * @param group
	 * @param dtoList
	 * @throws Exception
	 */
	public void execute(String group, Collection<TableDescBean> dtoList) throws Exception {
		group = group == null ? "" : group.trim();
		prepare();

		Collection<EntityDescBean> dtoExList = new ArrayList<EntityDescBean>(dtoList.size());
		//dtoBuilder.setGenDtoPackage(this.getGenDtoPackage());
		for (TableDescBean dto : dtoList) {
			EntityDescBean dtoEx = dtoBuilder.build(dto);
			dtoExList.add(dtoEx);
		}

		// String documentName = null;
		// DtoBuilder dtoBuilder = new DefaultDtoBuilder();
		// int i = 1;
		// for (File file : tableDefFiles) {
		// documentName = file.getName();
		// System.out.println("[" + documentName + "] start.");

		// Map<String, DtoBean> beans = tableExcelParser.parseExcelFile(file, dtoBuilder, new TableDtoAnnotationBuilder());
		// Map<String, DtoExBean> beans = null;
		// if (beans != null) {
		// Generate DDLs File
		// String allddlfileName = genDirSQLDDL + "ALL-DDL" + documentName.substring(0, documentName.lastIndexOf(".")) + ".sql";
		String allddlfileName = genDirSql + "ALLDDL" + group + ".sql";
		cgSqlBat.execute("dtos", dtoExList, allddlfileName);
		System.out.println("[" + allddlfileName + "] created.");

		// Generate Each DDL File
		for (EntityDescBean dto : dtoExList) {
			String ddlfileName = genDirSql + dto.getTblId() + ".sql";
			cgSql.execute("dto", dto, ddlfileName);
			System.out.println("[" + ddlfileName + "] created.");
		}
		// Generate SqlMap File
		for (EntityDescBean dto : dtoExList) {
			String sqlMapfileName = genDirSqlMap + dto.getTblId() + ".xml";
			cgSqlMap.execute("dto", dto, sqlMapfileName);
			System.out.println("[" + sqlMapfileName + "] created.");
		}
		// Generate Dto class
		for (EntityDescBean dto : dtoExList) {
			String packageName = dto.getClassPackage();
			String fileName = cgDto.createPackageDir(genDirJava, packageName) + dto.getClassId() + ".java";
			cgDto.execute("dto", dto, fileName);
			System.out.println("[" + fileName + "] created.");
		}

		// Generate Crud Service interface
		for (EntityDescBean dto : dtoExList) {
			String packageName = dto.getTableCrudServiceInterfacePackage();
			String fileName = cgCrudInterface.createPackageDir(genDirJava, packageName) + dto.getTableCrudServiceInterface() + ".java";
			cgCrudInterface.execute("dto", dto, fileName);
			System.out.println("[" + fileName + "] created.");
		}

		// Generate Crud Service implement class
		for (EntityDescBean dto : dtoExList) {
			String packageName = dto.getTableCrudServicePackage();
			String fileName = cgCrudClass.createPackageDir(genDirJava, packageName) + dto.getTableCrudServiceClass() + ".java";
			cgCrudClass.execute("dto", dto, fileName);
			System.out.println("[" + fileName + "] created.");
		}

		// Generate Crud Service Mapping File
		String mappingFileName = genDirResource + "entityServiceMapping" + group + ".properties";
		cgCrudMapping.execute("dtos", dtoExList, mappingFileName);
		System.out.println("[" + mappingFileName + "] created.");

		System.out.println("DDL,SqlMap,Dto,CrudService have been generated.");
	}

	/**
	 * @return the genDirResource
	 */
	public String getGenDirResource() {
		return genDirResource;
	}

	/**
	 * @param genDirResource
	 *            the genDirResource to set
	 */
	public void setGenDirResource(String genDirResource) {
		this.genDirResource = genDirResource;
	}

	/**
	 * @return the genDirJava
	 */
	public String getGenDirJava() {
		return genDirJava;
	}

	/**
	 * @param genDirJava
	 *            the genDirJava to set
	 */
	public void setGenDirJava(String genDirJava) {
		this.genDirJava = genDirJava;
	}

	/**
	 * @return the dtoBuilder
	 */
	public DtoBuilder getDtoBuilder() {
		return dtoBuilder;
	}

	/**
	 * @param dtoBuilder
	 *            the dtoBuilder to set
	 */
	public void setDtoBuilder(DtoBuilder dtoBuilder) {
		this.dtoBuilder = dtoBuilder;
	}

	/**
	 * @return the genDtoPackage
	 */
	public String getGenDtoPackage() {
		return genDtoPackage;
	}

	/**
	 * @param genDtoPackage the genDtoPackage to set
	 */
	public void setGenDtoPackage(String genDtoPackage) {
		this.genDtoPackage = genDtoPackage;
	}

	/**
	 * @return the genDirSql
	 */
	public String getGenDirSql() {
		return genDirSql;
	}

	/**
	 * @param genDirSql the genDirSql to set
	 */
	public void setGenDirSql(String genDirSql) {
		this.genDirSql = genDirSql;
	}

	/**
	 * @return the genDirSqlMap
	 */
	public String getGenDirSqlMap() {
		return genDirSqlMap;
	}

	/**
	 * @param genDirSqlMap the genDirSqlMap to set
	 */
	public void setGenDirSqlMap(String genDirSqlMap) {
		this.genDirSqlMap = genDirSqlMap;
	}

}
