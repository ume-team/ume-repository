package org.umeframework.dora.service.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.umeframework.dora.service.BaseRestController;

/**
 * Common restful entry for request pattern mapping "/rest/{system}/{resource}"
 *
 * @author Yue MA
 */
@RestController
@RequestMapping("rest/")
public class CommonRestController extends BaseRestController {
	/**
	 * doGet
	 * 
	 * @param request
	 * @param response
	 * @param system
	 * @param resource
	 * @param jsonInput
	 * @param printWriter
	 */
	@RequestMapping(value = "{system}/{resource}", method = RequestMethod.GET)
	public String doGet(
	        HttpServletRequest request,
	        HttpServletResponse response,
	        @PathVariable("system") String system,
	        @PathVariable("resource") String resource,
	        @RequestBody(required=false) String jsonInput,
	        PrintWriter printWriter) {
		return execute("GET", request, response, system, resource, jsonInput, system, printWriter);
	}
	/**
	 * doGetWithPathParam
	 * 
	 * @param request
	 * @param response
	 * @param system
	 * @param service
	 * @param jsonInput
	 * @param printWriter
	 */
	@RequestMapping(value = "{system}/{resource}/{jsonInput}", method = RequestMethod.GET)
	public String doGetWithPathParam(
	        HttpServletRequest request,
	        HttpServletResponse response,
	        @PathVariable("system") String system,
	        @PathVariable("resource") String resource,
	        @PathVariable("jsonInput") String jsonInput,
	        PrintWriter printWriter) {
		
		return execute("GET", request, response, system, resource, jsonInput, system, printWriter);
	}
	/**
	 * doPost
	 * 
	 * @param request
	 * @param response
	 * @param system
	 * @param resource
	 * @param jsonInput
	 * @param printWriter
	 */
	@RequestMapping(value = "{system}/{resource}", method = RequestMethod.POST, headers = { "content-type=application/json" })
	@ResponseBody
	public String doPost(
	        HttpServletRequest request,
	        HttpServletResponse response,
	        @PathVariable("system") String system,
	        @PathVariable("resource") String resource,
	        @RequestBody(required=false) String jsonInput,
	        PrintWriter printWriter) {
		return execute("POST", request, response, system, resource, jsonInput, system, printWriter);
	}
	/**
	 * doPut
	 * 
	 * @param request
	 * @param response
	 * @param system
	 * @param resource
	 * @param jsonInput
	 * @param printWriter
	 */
	@RequestMapping(value = "{system}/{resource}", method = RequestMethod.PUT, headers = { "content-type=application/json" })
	@ResponseBody
	public String doPut(
	        HttpServletRequest request,
	        HttpServletResponse response,
	        @PathVariable("system") String system,
	        @PathVariable("resource") String resource,
	        @RequestBody(required=false) String jsonInput,
	        PrintWriter printWriter) {
		return execute("PUT", request, response, system, resource, jsonInput, system, printWriter);
	}

	/**
	 * doDelete
	 * 
	 * @param request
	 * @param response
	 * @param system
	 * @param resource
	 * @param jsonInput
	 * @param printWriter
	 */
	@RequestMapping(value = "{system}/{resource}", method = RequestMethod.DELETE, headers = { "content-type=application/json" })
	@ResponseBody
	public String doDelete(
	        HttpServletRequest request,
	        HttpServletResponse response,
	        @PathVariable("system") String system,
	        @PathVariable("resource") String resource,
	        @RequestBody(required=false) String jsonInput,
	        PrintWriter printWriter) {
		return execute("DELETE", request, response, system, resource, jsonInput, system, printWriter);
	}

}
