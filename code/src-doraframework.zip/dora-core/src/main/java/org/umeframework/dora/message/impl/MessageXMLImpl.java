package org.umeframework.dora.message.impl;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.xmlrules.DigesterLoader;
import org.umeframework.dora.exception.SystemException;

/**
 * Message properties implementing by XML file
 * 
 * @author Yue MA
 */
public class MessageXMLImpl extends BaseMessageProperties {
    /**
     * XML rule define
     */
    private static final String RULE_MAPPING_DEFINE = MessageXMLImpl.class.getPackage().getName().replace(".", "/") + "/xmlMessageRule.xml";
    /**
     * Digester instance prepare
     */
    private static final Digester defaultDigester = DigesterLoader.createDigester(MessageXMLImpl.class.getClassLoader().getResource(RULE_MAPPING_DEFINE));

    /**
     * Constructor
     * 
     * @param msgResources
     */
    public MessageXMLImpl(
            String msgResources) throws SystemException {
        super(msgResources);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.properties.impl.AbstractMessageProperties#
     * loadResourceAsMap(java.lang.String)
     */
    @Override
    protected Map<String, String> loadResourceAsMap(
            String msgResources) throws SystemException {
        // Get url
        URL resourceUrl = Thread.currentThread().getContextClassLoader().getResource(msgResources + ".xml");
        // Parse XML file
        XMLMessageBeans beans = null;
        try {
            beans = (XMLMessageBeans) defaultDigester.parse(resourceUrl);
            Map<String, String> msgs = new HashMap<String, String>();
            for (XMLMessageBean bean : beans.getBeans()) {
                String key = bean.getId();
                String value = bean.getText();
                msgs.put(key, value);
            }
            return msgs;
        } catch (Exception e) {
            throw new SystemException(e, "Failed to load XML message resource[" + msgResources + "].");
        }
    }

}
