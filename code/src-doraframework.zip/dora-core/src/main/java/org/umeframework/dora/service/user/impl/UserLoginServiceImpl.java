package org.umeframework.dora.service.user.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.umeframework.dora.cache.CacheManager;
import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.exception.AuthenticationException;
import org.umeframework.dora.service.BaseComponent;
import org.umeframework.dora.service.UserEntity;
import org.umeframework.dora.service.user.UserAuthenticator;
import org.umeframework.dora.service.user.UserLoginService;
import org.umeframework.dora.util.CodecUtil;
import org.umeframework.dora.util.DateUtil;
import org.umeframework.dora.util.StringUtil;

/**
 * Service login/logout common implementation.<br>
 *
 * @author Yue MA
 */
public class UserLoginServiceImpl extends BaseComponent implements UserLoginService {
	/**
	 * User authenticator
	 */
	@Qualifier("userAuthenticator")
	@Autowired(required = false)
	private UserAuthenticator<UserEntity> userAuthenticator;
	/**
	 * Cache manager instance
	 */
	@Resource(name = "cacheManager")
	private CacheManager cacheManager;
	/**
	 * Key of cached user map
	 */
	private String cacheTokenKey = this.getClass().getName() + ".TokenMap.Key";

	/**
	 * Disable user login in on multiple browser
	 */
	private boolean singleLogin = false;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserLoginService#login(java.lang.String, java.lang.String)
	 */
	@Override
	synchronized public UserEntity login(String loginId, String loginPassword, String... options) {
		if (userAuthenticator == null) {
			throw new AuthenticationException("Authentication failed: user authenticator configuration was not setup.");
		}
		Timestamp transactionStartTime = super.getTransactionStartTime();
		// do authentication
		UserEntity userObj = userAuthenticator.getUserObject(loginId, loginPassword, options);
		if (userObj == null) {
			throw new AuthenticationException("Authentication failed: no user object return from authentication.");
		}
		if (userObj.getUid() == null) {
			userObj.setUid(loginId);
		}
		if (userObj.getLastTransactionTime() == null) {
			userObj.setLastTransactionTime(transactionStartTime);
		}
		// updateLoginStatus(sysUser);
		if (StringUtil.isEmpty(userObj.getToken())) {
			// use default token generate rule if no business token provided
			String token = CodecUtil.encodeMD5Hex(DateUtil.dateToString(transactionStartTime, DateUtil.FORMAT.YYYYMMDDHHMMSSMMM))
			        + System.currentTimeMillis();
			userObj.setToken(token);
		}
		// Set internal token into context
		SessionContext.open().set(SessionContext.Key.Token, userObj.getToken());

		if (singleLogin) {
			// check multiple login
			int cnt = this.deleteTokenByUID(userObj.getUid());
			if (cnt > 0) {
				super.getLogger().info("Remove previous login status of current user.");
			}
		}
		this.setUserObject(userObj.getToken(), userObj);

//		// do authentication
//		userAuthenticator.doAuthorization(userObj, options);
		super.getLogger().info("User login: ", loginId);
		return userObj;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserLoginService#logout(java.lang.String)
	 */
	@Override
	synchronized public void logout(String loginId) {
		this.deleteTokenByUID(loginId);
		// updateLogoutStatus(sysUserId);
		super.createMessage(loginId + " exit system.");
		super.getLogger().info("User logout: ", loginId);
	}

	/**
	 * initialize
	 */
	private void init() {
		try {
			Map<String, UserEntity> tokenMap = new ConcurrentHashMap<String, UserEntity>();
			cacheManager.set(cacheTokenKey, tokenMap);
			getLogger().info("Initialized cache of token map");
		} catch (Exception ex) {
			getLogger().error("CacheManager instance init failed.", ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#get(java.lang.String)
	 */
	@Override
	public UserEntity getUserObject(String token) {
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);
		if (tokenMap == null) {
			getLogger().warn("No found token map.");
			return null;
		}

		if (token == null) {
			getLogger().warn("Token was null.");
			return null;
		}

		if (!tokenMap.containsKey(token)) {
			getLogger().warn("No found cached user with token:" + token);
			return null;
		}
		return tokenMap.get(token);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#set(java.lang.String, org.umeframework.dora.service.UserObject)
	 */
	@Override
	public void setUserObject(String token, UserEntity user) {
		if (cacheManager.get(cacheTokenKey) == null) {
			init();
		}
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);

		if (tokenMap == null) {
			getLogger().error("No found token map in Cache Manager.");
			return;
		}

		tokenMap.put(token, user);
		cacheManager.set(cacheTokenKey, tokenMap);

		getLogger().debug("Updated user " + token + "," + user.getUid());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#getCachedUIDs()
	 */
	@Override
	public String[] getCachedUIDs() {
		Set<String> uidSet = new HashSet<String>();
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);
		if (tokenMap != null) {
			synchronized (cacheTokenKey) {
				for (Map.Entry<String, UserEntity> entry : tokenMap.entrySet()) {
					UserEntity user = entry.getValue();
					if (user != null) {
						uidSet.add(user.getUid());
					}
				}
			}
		}
		return uidSet.size() == 0 ? null : uidSet.toArray(new String[uidSet.size()]);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#deleteToken(java.lang.String)
	 */
	@Override
	public int deleteUserObject(String token) {
		int result = 0;
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);
		if (tokenMap != null) {
			synchronized (cacheTokenKey) {
				if (tokenMap.containsKey(token)) {
					tokenMap.remove(token);
					result = 1;
					getLogger().debug("Remove cached user " + token);
				}
			}
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#replace(java.lang.String, java.lang.String, org.umeframework.dora.service.UserObject)
	 */
	@Override
	public void renewUserObject(String oldToken, String newToken, UserEntity user) {
		if (cacheManager.get(cacheTokenKey) == null) {
			init();
		}
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);

		if (tokenMap == null) {
			getLogger().error("No found token map in Cache Manager.");
			return;
		}
		synchronized (cacheTokenKey) {
			tokenMap.remove(oldToken);
		}

		tokenMap.put(newToken, user);
		cacheManager.set(cacheTokenKey, tokenMap);

		getLogger().debug("Updated user " + oldToken + "/" + newToken + "," + user.getUid());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#deleteTokenByUID(java.lang.String)
	 */
	@Override
	public int deleteTokenByUID(String uid) {
		int count = 0;
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);
		if (tokenMap != null) {
			for (Map.Entry<String, UserEntity> entry : tokenMap.entrySet()) {
				String token = entry.getKey();
				UserEntity user = entry.getValue();
				if (user != null && user.getUid().equals(uid)) {
					deleteUserObject(token);
					count++;
				}
			}
		}
		return count;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#getTokenByUID(java.lang.String)
	 */
	@Override
	public String[] getTokenByUID(String uid) {
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);
		if (tokenMap != null && StringUtil.isEmpty(uid)) {
			return tokenMap.keySet().toArray(new String[tokenMap.keySet().size()]);
		}
		List<String> tokens = new ArrayList<String>();
		if (tokenMap != null) {
			for (Map.Entry<String, UserEntity> entry : tokenMap.entrySet()) {
				String token = entry.getKey();
				UserEntity user = entry.getValue();
				if (user != null && user.getUid().equals(uid)) {
					tokens.add(token);
				}
			}
		}
		return tokens.size() == 0 ? null : tokens.toArray(new String[tokens.size()]);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.com.UserCacheService#deleteInactiveTokens(int)
	 */
	@Override
	public int deleteInactiveToken(int inactiveSecond) {
		int count = 0;
		long inactiveMillisecond = inactiveSecond * 1000;
		long currentTime = getCurrentTimestamp().getTime();
		Map<String, UserEntity> tokenMap = cacheManager.get(cacheTokenKey);
		if (tokenMap != null) {
			for (Map.Entry<String, UserEntity> entry : tokenMap.entrySet()) {
				String token = entry.getKey();
				UserEntity user = entry.getValue();
				long dvalue = currentTime - user.getLastTransactionTime().getTime();
				if (dvalue >= inactiveMillisecond) {
					deleteUserObject(token);
					count++;
				}
			}
		}
		return count;
	}

	/**
	 * @return the userAuthenticator
	 */
	public UserAuthenticator<UserEntity> getUserAuthenticator() {
		return userAuthenticator;
	}

	/**
	 * @param userAuthenticator
	 *            the userAuthenticator to set
	 */
	public void setUserAuthenticator(UserAuthenticator<UserEntity> userAuthenticator) {
		this.userAuthenticator = userAuthenticator;
	}

	/**
	 * @return the singleLogin
	 */
	public boolean isSingleLogin() {
		return singleLogin;
	}

	/**
	 * @param singleLogin
	 *            the singleLogin to set
	 */
	public void setSingleLogin(boolean singleLogin) {
		this.singleLogin = singleLogin;
	}

	/**
	 * getCacheManager
	 *
	 * @return the cacheManager
	 */
	public CacheManager getCacheManager() {
		return cacheManager;
	}

	/**
	 * setCacheManager
	 *
	 * @param cacheManager
	 *            the cacheManager to set
	 */
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

	/**
	 * @return the cacheTokenKey
	 */
	public String getCacheTokenKey() {
		return cacheTokenKey;
	}

	/**
	 * @param cacheTokenKey
	 *            the cacheTokenKey to set
	 */
	public void setCacheTokenKey(String cacheTokenKey) {
		this.cacheTokenKey = cacheTokenKey;
	}

}
