package org.umeframework.dora.service.interceptor;

/**
 * Intercept interface declare.<br>
 * 
 * @author Yue MA
 */
public interface Interceptor {
    /**
     * Intercept entry
     * 
     * @param chain
     *            - InterceptorChain instance for all intercept instances use
     */
    void intercept(
            InterceptorChain chain) throws Throwable;
}
