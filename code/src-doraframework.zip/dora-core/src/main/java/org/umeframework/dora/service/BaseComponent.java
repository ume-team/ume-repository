package org.umeframework.dora.service;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.exception.ApplicationException;
import org.umeframework.dora.log.Logger;
import org.umeframework.dora.message.MessageProperties;

/**
 * Common service component function define
 *
 * @author Yue MA
 */
public abstract class BaseComponent {
	/**
	 * logger
	 */
	@Autowired(required = false)
	@Qualifier("logger")
	private Logger logger;
	/**
	 * message properties
	 */
	@Autowired(required = false)
	@Qualifier("messageProperties")
	private MessageProperties messageProperties;

	/**
	 * Append message to service context
	 *
	 * @param message - message ID or message content
	 * @param parameters - message options
	 */
	protected void createMessage(String message, Object... parameters) {
		MessageProperties messageProperties = getMessageProperties();
		String text = messageProperties.get(message, parameters);
		SessionContext.open().addMessage(text != null ? text : message);
	}
	
	/**
	 * Throw application exception
	 * 
	 * @param message - message ID or message content
	 * @param parameters - message options
	 */
	protected void createApplicationException(String message, Object... parameters) {
		throw new ApplicationException(message, parameters);
	}

	/**
	 * Throw application exception
	 * 
	 * @param cause - exception instance
	 * @param message - message ID or message content
	 * @param parameters - message options
	 */
	protected void createApplicationException(Throwable cause, String message, Object... parameters) {
		throw new ApplicationException(cause, message, parameters);
	}

	/**
	 * Get current user ID
	 *
	 * @return
	 */
	public String getUid() {
		return getContextParam(SessionContext.Key.UID);
	}

	/**
	 * Get current system ID
	 *
	 * @return
	 */
	public String getSysId() {
		return getContextParam(SessionContext.Key.SysId);
	}

	/**
	 * Get current service ID
	 *
	 * @return
	 */
	public String getServiceId() {
		return getContextParam(SessionContext.Key.ServiceId);
	}

	/**
	 * Get parameter from request's session context (transfer by the ThreadLocal instance)
	 * 
	 * @param key
	 * @return
	 */
	public String getContextParam(SessionContext.Key key) {
		return SessionContext.open().get(key);
	}

	/**
	 * get transaction start time
	 *
	 * @return
	 */
	protected Timestamp getTransactionStartTime() {
		return SessionContext.open().get(SessionContext.Key.TransactionTime);
	}

	/**
	 * get current time
	 *
	 * @return
	 */
	protected Timestamp getCurrentTimestamp() {
		return new Timestamp(System.currentTimeMillis());
	}

	/**
	 * @return the messageProperties
	 */
	public MessageProperties getMessageProperties() {
		return messageProperties;
	}

	/**
	 * @param messageProperties
	 *            the messageProperties to set
	 */
	public void setMessageProperties(MessageProperties messageProperties) {
		this.messageProperties = messageProperties;
	}

	/**
	 * @return the appLogger
	 */
	public Logger getLogger() {
		return logger;
	}

	/**
	 * @param appLogger
	 *            the appLogger to set
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}
