package org.umeframework.dora.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.umeframework.dora.dao.RdbDao;

/**
 * Common data access service component function define
 *
 * @author Yue MA
 */
public abstract class BaseDBComponent extends BaseComponent {
	/**
	 * RdbDao
	 */
	@Autowired(required = false)
	@Qualifier("dao")
	private RdbDao dao;

	/**
	 * @return the dao
	 */
	public RdbDao getDao() {
		return dao;
	}

}
