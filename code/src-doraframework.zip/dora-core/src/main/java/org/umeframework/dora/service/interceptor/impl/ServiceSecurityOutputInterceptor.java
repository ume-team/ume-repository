package org.umeframework.dora.service.interceptor.impl;

import org.umeframework.dora.security.Encryptor;
import org.umeframework.dora.service.ServiceResponse;
import org.umeframework.dora.service.interceptor.InterceptorChain;

/**
 * Service security output parameter processor.<br>
 * 
 * @author Yue MA
 * 
 */
public class ServiceSecurityOutputInterceptor extends ServiceOutputInterceptor {

	/**
	 * Encryptor
	 */
	private Encryptor encryptor;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.web.interceptor.Interceptor#intercept(tora.
	 * fw.web.interceptor.InterceptorChain)
	 */
	@Override
	public void intercept(InterceptorChain chain) throws Exception {
		ServiceResponse<Object> serviceResponse = chain.getServiceResponse();
		if (encryptor != null) {
			String resultObjectAsEncryptStr = super.getAjaxRender().render(serviceResponse.getResultObject());
			resultObjectAsEncryptStr = encryptor.encrypt(resultObjectAsEncryptStr);
			serviceResponse.setResultObject(resultObjectAsEncryptStr);
			chain.setServiceResponse(serviceResponse);
		}
		super.intercept(chain);
	}

	/**
	 * @return the encryptor
	 */
	public Encryptor getEncryptor() {
		return encryptor;
	}

	/**
	 * @param encryptor the encryptor to set
	 */
	public void setEncryptor(Encryptor encryptor) {
		this.encryptor = encryptor;
	}
}
