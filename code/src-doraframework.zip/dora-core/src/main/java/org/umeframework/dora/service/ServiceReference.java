package org.umeframework.dora.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.umeframework.dora.transaction.TransactionRequired;

/**
 * ServiceReference
 * 
 * @author Yue MA
 * 
 */
public class ServiceReference implements java.io.Serializable {
    /**
	 * serial version UID
	 */
	private static final long serialVersionUID = -1506280058787497970L;
	/**
     * serviceInstance
     */
    private Object serviceInstance;
    /**
     * serviceClazz
     */
    private Class<?> serviceClazz;
    /**
     * serviceMethod
     */
    private Method serviceMethod;
    /**
     * authenticate flag
     */
    private boolean authenticate = true;
    /**
     * disable flag
     */
    private boolean disable = false;

    /**
     * WebServiceProxy
     * 
     * @param serviceInstance
     * @param serviceMethod
     */
    public ServiceReference(
            Object serviceInstance,
            Method serviceMethod) {
        this.serviceInstance = serviceInstance;
        this.serviceMethod = serviceMethod;
        this.serviceClazz = serviceInstance.getClass();
    }

    /**
     * required transaction judge
     * 
     * @return
     */
    public boolean isTransactional() {
        TransactionRequired tx = serviceMethod.getAnnotation(TransactionRequired.class);
        return tx != null;
    }

    /**
     * getServiceMethod
     * 
     * @return
     */
    public Method getServiceMethod() {
        return serviceMethod;
    }

    /**
     * getServiceInstance
     * 
     * @return
     */
    public Object getServiceInstance() {
        return serviceInstance;
    }

    /**
     * execute
     * 
     * @param methodParam
     * @return
     * @throws Throwable
     */
    public Object execute(
            Object... methodParam) throws Throwable {
        Object output = null;
        try {
            output = serviceMethod.invoke(serviceInstance, methodParam);
        } catch (IllegalAccessException e) {
            throw e;
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (InvocationTargetException e) {
            throw e.getTargetException();
        }
        return output;
    }

    /**
     * @return the authenticate
     */
    public boolean isAuthenticate() {
        return authenticate;
    }

    /**
     * @param authenticate the authenticate to set
     */
    public void setAuthenticate(
            boolean authenticate) {
        this.authenticate = authenticate;
    }

    /**
     * @return the disable
     */
    public boolean isDisable() {
        return disable;
    }

    /**
     * @param disable the disable to set
     */
    public void setDisable(
            boolean disable) {
        this.disable = disable;
    }

    /**
     * @return the serviceClazz
     */
    public Class<?> getServiceClazz() {
        return serviceClazz;
    }
}
