package org.umeframework.dora.service.user;

import org.umeframework.dora.service.UserEntity;

/**
 * Service login/logout common interface declare.<br>
 *
 * @author Yue MA
 */
public interface UserLoginService {
    /**
     * Implement the common login service once UserAuthenticator has been injected.
     * 
     * @param loginId
     * @param loginPassword
     * @return
     */
    UserEntity login(
            String loginId,
            String loginPassword,
            String...options);

    /**
     * Implement the common logout service once UserAuthenticator has been injected.
     * 
     * @param loginId
     */
    void logout(
            String loginId);
    
	/**
	 * Get user object by token
	 *
	 * @param token
	 * @return
	 */
	UserEntity getUserObject(String token);

	/**
	 * Set user object by token
	 *
	 * @param token
	 * @param user
	 */
	void setUserObject(String token, UserEntity user);

	/**
	 * Get all cached UID
	 *
	 * @return
	 */
	String[] getCachedUIDs();

	/**
	 * Get all cached tokens by UID
	 * 
	 * @param uid
	 * @return
	 */
	String[] getTokenByUID(String uid);

	/**
	 * Delete cached user object by token
	 *
	 * @param token
	 */
	int deleteUserObject(String token);

	/**
	 * Set user object by newToken and remove oldToken information
	 * 
	 * @param oldToken
	 * @param newToken
	 * @param user
	 */
	void renewUserObject(String oldToken, String newToken, UserEntity user);

	/**
	 * Delete all cached tokens by UID
	 *
	 * @param uid
	 */
	int deleteTokenByUID(String uid);

	/**
	 * Delete inactive tokens in cache
	 *
	 * @param inactiveSecond
	 * @return
	 */
	int deleteInactiveToken(int inactiveSecond);    
    
}
