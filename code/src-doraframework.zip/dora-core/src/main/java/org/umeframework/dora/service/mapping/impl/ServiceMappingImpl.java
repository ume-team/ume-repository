package org.umeframework.dora.service.mapping.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.BeansException;
import org.umeframework.dora.bean.BeanFactory;
import org.umeframework.dora.exception.ExceptionHandler;
import org.umeframework.dora.exception.SystemException;
import org.umeframework.dora.exception.TransactionException;
import org.umeframework.dora.property.ConfigProperties;
import org.umeframework.dora.service.BaseComponent;
import org.umeframework.dora.service.ServiceReference;
import org.umeframework.dora.service.ServiceResponse;
import org.umeframework.dora.service.mapping.ServiceMapping;
import org.umeframework.dora.transaction.TransactionManager;
import org.umeframework.dora.util.ReflectUtil;

/**
 * Initial web service define information base service define in
 * serviceMappingProperties.properties
 *
 * @author Yue MA
 */
public class ServiceMappingImpl extends BaseComponent implements ServiceMapping {
	/**
	 * split char of service class package
	 */
	private static final String WEB_SERVICE_CLASS_PKG_SPLIT_CHAR = ".";
	/**
	 * split char of service properties elements define
	 */
	private static final String WEB_SERVICE_PROPERTY_SPLIT_CHAR = ",";
	/**
	 * split char of service class name and method name
	 */
	private static final String WEB_SERVICE_CLASS_METHOD_SPLIT_CHAR = "#";
	/**
	 * service define and status management map
	 */
	private final Map<String, ServiceReference> serviceContainer = new HashMap<String, ServiceReference>();
	
	/**
	 * beanFactory
	 */
	@Resource(name="beanFactory")
	private BeanFactory beanFactory;

	/**
	 * serviceMappingProperties
	 */
	@Resource(name="serviceMappingConfigProperties")
	private ConfigProperties serviceMappingConfigProperties;
	
	/**
	 * exceptionHandler
	 */
	@Resource(name="exceptionHandler")
	private ExceptionHandler exceptionHandler;

	/**
	 * @throws SystemException
	 */
	public void init() throws SystemException {
		try {
			// Initialize all service instance define in
			// serviceMappingProperties
			for (String serviceId : serviceMappingConfigProperties.keySet()) {
				String serviceValue = serviceMappingConfigProperties.get(serviceId);
				initServiceMapping(serviceId, serviceValue);
				ServiceReference proxy = serviceContainer.get(serviceId);

				getLogger().info("Initialized " + serviceId + "," + (proxy.isDisable() ? "disable" : "enable"));

			}

			getLogger().info("Service mapping initialize successful.");

		} catch (Exception e) {
			getLogger().error("Service mapping initialize failed.", e);
			throw new SystemException(e, "service mapping initialize failed.");
		} finally {
		}
	}

	/**
	 * destroy
	 */
	public void destroy() {
		try {
			// destroy serviceMapping resources
			serviceContainer.clear();
			getLogger().info("[Service destroy] service mapping destroy successful.");
		} catch (Exception e) {
			getLogger().error("[Service destroy] service mapping destroy failed.", e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.WebServiceHelper#addWebService(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public void addService(String serviceId, String serviceValue) throws SystemException {
		if (!serviceMappingConfigProperties.containsKey(serviceId)) {
			serviceMappingConfigProperties.set(serviceId, serviceValue);
		}
		initServiceMapping(serviceId, serviceValue);
		saveServiceMapping();
	}

	/**
	 * initialize service mapping from properties file
	 * 
	 * @param serviceId
	 * @param serviceValue
	 * @throws SystemException
	 */
	protected void initServiceMapping(String serviceId, String serviceValue) throws SystemException {
		if (!isValidServiceId(serviceId)) {
			getLogger().error("Service mapping initialize error: id contain non-alpha-number char.");
			throw new SystemException("Service mapping initialize error: id contain non-alpha-number char.");
		}

		serviceValue = serviceValue.contains(";") ? serviceValue.replace(";", WEB_SERVICE_PROPERTY_SPLIT_CHAR) : serviceValue;

		String[] elements = null;
		if (serviceValue.contains(WEB_SERVICE_PROPERTY_SPLIT_CHAR)) {
			elements = serviceValue.split(WEB_SERVICE_PROPERTY_SPLIT_CHAR);
		} else {
			elements = new String[] { serviceValue.trim() };
		}

		String serviceClassMethod = elements[0];
		String serviceBeanName = serviceClassMethod.split(WEB_SERVICE_CLASS_METHOD_SPLIT_CHAR)[0];
		String serviceMethodName = serviceClassMethod.split(WEB_SERVICE_CLASS_METHOD_SPLIT_CHAR)[1];

		Class<?> serviceClazz = null;
		Method serviceMethod = null;
		Object serviceInstance = null;
		if (!serviceBeanName.contains(WEB_SERVICE_CLASS_PKG_SPLIT_CHAR)) {
			try {
				serviceInstance = beanFactory.getBean(serviceBeanName);
				serviceClazz = serviceInstance.getClass();
			} catch (BeansException e) {
				throw new SystemException(e, "No found bean instance in factory:" + serviceBeanName);
			}
		} else {
			try {
				serviceClazz = Thread.currentThread().getContextClassLoader().loadClass(serviceBeanName);
				serviceInstance = beanFactory.autowireCapableCreateBean(serviceClazz);
			} catch (Exception e) {
				throw new SystemException(e, "Failed in create instance for service class:" + serviceBeanName);
			}
		}
		serviceMethod = ReflectUtil.getNonBridgeMethod(serviceClazz, serviceMethodName);
		if (serviceMethod == null) {
			throw new SystemException("No found service method:" + serviceBeanName + "." + serviceMethodName);
		}

		ServiceReference proxy = new ServiceReference(serviceInstance, serviceMethod);

		if (elements.length > 1) {
			if (elements[1].trim().equalsIgnoreCase("false")) {
				proxy.setAuthenticate(false);
			}
			if (elements[1].trim().equalsIgnoreCase("disable")) {
				proxy.setDisable(true);
			}
		}
		if (elements.length > 2) {
			if (elements[2].trim().equalsIgnoreCase("false")) {
				proxy.setAuthenticate(false);
			}
			if (elements[2].trim().equalsIgnoreCase("disable")) {
				proxy.setDisable(true);
			}
		}
		serviceContainer.put(serviceId, proxy);
	}
	
	/**
	 * isValidServiceId
	 * 
	 * @param serviceId
	 * @return
	 */
	protected boolean isValidServiceId(String serviceId) {
		if (StringUtils.isEmpty(serviceId)) {
			return false;
		}
		String regexp = "^([0-9]|[a-z]|[A-Z]|-|_)*$";
		if (!GenericValidator.matchRegexp(serviceId, regexp)) {
			return false;
		}
		return true;
	}

	/**
	 * Save service mapping into properties file
	 */
	protected void saveServiceMapping() {
		try {
			serviceMappingConfigProperties.save();
		} catch (Exception e) {
			getLogger().error("[Service save] service mapping save failed.", e);
		} finally {
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.umeframework.dora.service.WebServiceHelper#getWebServiceProxy(java.lang.String)
	 */
	@Override
	public ServiceReference getServiceReference(String serviceId) {
		ServiceReference serviceProxy = serviceContainer.get(serviceId);
		return serviceProxy;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.WebServiceHelper#runWebService(java.lang.String,
	 * java.lang.Object[])
	 */
	@Override
	public ServiceResponse<Object> runService(String serviceId, Object[] methodParam) throws Throwable {
		ServiceReference serviceRef = getServiceReference(serviceId);
		ServiceResponse<Object> serviceResponse = new ServiceResponse<Object>();
		try {
			Object output = serviceRef.execute(methodParam);
			serviceResponse.setResultCode(ServiceResponse.SUCCESS);
			serviceResponse.setResultObject(output);
		} catch (Throwable cause) {
			if (cause instanceof InvocationTargetException) {
				cause = ((InvocationTargetException) cause).getTargetException();
			}
			throw cause;
		}
		return serviceResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.umeframework.dora.service.WebServiceHelper#runWebServiceWithExceptionHandler(java.
	 * lang.String, java.lang.Object[], java.util.Map)
	 */
	public ServiceResponse<Object> runTransactionalService(
	        String serviceId,
	        Object[] methodParam,
	        TransactionManager transactionManager,
	        Map<String, ExceptionHandler> exceptionHandlers) {
		ServiceReference serviceRef = getServiceReference(serviceId);
		ServiceResponse<Object> serviceResponse = new ServiceResponse<Object>();
		try {
			if (serviceRef.isTransactional()) {
				// Do transaction begin
				transactionManager.begin();
			}
			Object output = serviceRef.execute(methodParam);
			serviceResponse.setResultCode(ServiceResponse.SUCCESS);
			serviceResponse.setResultObject(output);
			if (serviceRef.isTransactional()) {
				// Do transaction success
				transactionManager.commit();
			}
		} catch (Throwable e) {
			if (serviceRef.isTransactional() && !(e instanceof TransactionException)) {
				// Do transaction fail
				transactionManager.rollback();
			}
			if (e instanceof InvocationTargetException) {
				e = ((InvocationTargetException) e).getTargetException();
			}
			// create CommonServiceResponse for save exception information
			serviceResponse = new ServiceResponse<Object>();
			if (exceptionHandler != null) {
				exceptionHandler.handleException(serviceResponse, e);
			}
		}
		return serviceResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.WebServiceHelper#enableWebService(java.lang.String)
	 */
	@Override
	public void enableService(String serviceId) {
		serviceContainer.get(serviceId).setDisable(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.umeframework.dora.service.WebServiceHelper#disableWebService(java.lang.String)
	 */
	@Override
	public void disableService(String serviceId) {
		serviceContainer.get(serviceId).setDisable(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.WebServiceHelper#getEnableWebServices()
	 */
	public String[] getEnableServiceList() {
		Set<String> set = new HashSet<String>();
		for (String id : serviceContainer.keySet()) {
			ServiceReference proxy = serviceContainer.get(id);
			if (!proxy.isDisable()) {
				set.add(id);
			}
		}
		return set.toArray(new String[set.size()]);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.WebServiceHelper#getDisableWebServices()
	 */
	public String[] getDisableServiceList() {
		Set<String> set = new HashSet<String>();
		for (String id : serviceContainer.keySet()) {
			ServiceReference proxy = serviceContainer.get(id);
			if (proxy.isDisable()) {
				set.add(id);
			}
		}
		return set.toArray(new String[set.size()]);
	}

	/**
	 * @return the beanFactory
	 */
	public BeanFactory getBeanFactory() {
		return beanFactory;
	}

	/**
	 * @param beanFactory
	 *            the beanFactory to set
	 */
	public void setBeanFactory(BeanFactory beanFactory) {
		this.beanFactory = beanFactory;
	}

	/**
	 * @return the serviceMappingConfigProperties
	 */
	public ConfigProperties getServiceMappingConfigProperties() {
		return serviceMappingConfigProperties;
	}

	/**
	 * @param serviceMappingConfigProperties
	 *            the serviceMappingConfigProperties to set
	 */
	public void setServiceMappingConfigProperties(ConfigProperties serviceMappingConfigProperties) {
		this.serviceMappingConfigProperties = serviceMappingConfigProperties;
	}

	/**
	 * @return the exceptionHandler
	 */
	public ExceptionHandler getExceptionHandler() {
		return exceptionHandler;
	}

	/**
	 * @param exceptionHandler the exceptionHandler to set
	 */
	public void setExceptionHandler(ExceptionHandler exceptionHandler) {
		this.exceptionHandler = exceptionHandler;
	}

}
