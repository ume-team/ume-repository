package org.umeframework.dora.log.impl;

import java.io.IOException;

import org.apache.log4j.Layout;
import org.apache.log4j.RollingFileAppender;

/**
 * NodeRollingLogAppender
 * 
 * @author Yue MA
 */
@Deprecated
public class NodeRollingLogAppender extends RollingFileAppender {

    /**
     * NODE_ID
     */
    private static final String NODE_ID = String.valueOf(System.getProperty("nodeid") == null ? "1" : System.getProperty("nodeid"));

    /**
     * NODE_ID_TOKEN
     */
    private static final String NODE_ID_TOKEN = "\\$nodeid\\$";

    /**
     * replaceNodeId
     * 
     * @param fileName
     */
    public static String replaceNodeId(
            String fileName) {
        return fileName.replaceAll(NODE_ID_TOKEN, NODE_ID);
    }

    /**
     * NodeRollingLogAppender
     */
    public NodeRollingLogAppender() {
        super();
    }

    /**
     * NodeRollingLogAppender
     * 
     * @param layout
     * @param fileName
     * @throws IOException
     */
    public NodeRollingLogAppender(
            Layout layout,
            String fileName) throws IOException {
        super(layout, replaceNodeId(fileName));
    }

    /**
     * NodeRollingLogAppender
     * 
     * @param layout
     * @param fileName
     * @param append
     * @throws IOException
     */
    public NodeRollingLogAppender(
            Layout layout,
            String fileName,
            boolean append) throws IOException {
        super(layout, replaceNodeId(fileName), append);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.log4j.FileAppender#getFile()
     */
    @Override
    public synchronized String getFile() {
        return replaceNodeId(super.getFile());
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.log4j.FileAppender#setFile(java.lang.String)
     */
    @Override
    public void setFile(
            String fileName) {
        super.setFile(replaceNodeId(fileName));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.log4j.RollingFileAppender#setFile(java.lang.String,
     * boolean, boolean, int)
     */
    @Override
    public synchronized void setFile(
            String fileName,
            boolean append,
            boolean bufferedIO,
            int bufferSize) throws IOException {
        super.setFile(replaceNodeId(fileName), append, bufferedIO, bufferSize);
    }

}
