package org.umeframework.dora.service.user;
//package org.umeframework.dora.service;
//
///**
// * UserCacheService
// *
// * @author Yue MA
// *
// */
//public interface UserCacheService {
//	/**
//	 * Get user object by token
//	 *
//	 * @param token
//	 * @return
//	 */
//	UserObject getUserObject(String token);
//
//	/**
//	 * Set user object by token
//	 *
//	 * @param token
//	 * @param user
//	 */
//	void setUserObject(String token, UserObject user);
//
//	/**
//	 * Get all cached UID
//	 *
//	 * @return
//	 */
//	String[] getCachedUIDs();
//
//	/**
//	 * Get all cached tokens by UID
//	 * 
//	 * @param uid
//	 * @return
//	 */
//	String[] getTokenByUID(String uid);
//
//	/**
//	 * Delete cached user object by token
//	 *
//	 * @param token
//	 */
//	int deleteUserObject(String token);
//
//	/**
//	 * Set user object by newToken and remove oldToken information
//	 * 
//	 * @param oldToken
//	 * @param newToken
//	 * @param user
//	 */
//	void renewUserObject(String oldToken, String newToken, UserObject user);
//
//	/**
//	 * Delete all cached tokens by UID
//	 *
//	 * @param uid
//	 */
//	int deleteTokenByUID(String uid);
//
//	/**
//	 * Delete inactive tokens in cache
//	 *
//	 * @param inactiveSecond
//	 * @return
//	 */
//	int deleteInactiveToken(int inactiveSecond);
//
//}
