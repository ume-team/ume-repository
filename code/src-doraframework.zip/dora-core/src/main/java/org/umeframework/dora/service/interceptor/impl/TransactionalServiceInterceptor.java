package org.umeframework.dora.service.interceptor.impl;

import org.umeframework.dora.service.ServiceReference;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.transaction.TransactionManager;

/**
 * TransactionalServiceInterceptor
 *
 * @author Yue MA
 *
 */
public class TransactionalServiceInterceptor extends ServiceInterceptor implements Interceptor {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.interceptor.impl.ServiceInterceptor#beginTransaction(org.umeframework.dora.service.ServiceReference)
	 */
	@Override
	protected void beginTransaction(ServiceReference serviceRef) {
		// Do transaction begin
		TransactionManager transactionManager = super.getTransactionManager();
		if (transactionManager != null) {
			transactionManager.begin();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.interceptor.impl.ServiceInterceptor#commitTransaction(org.umeframework.dora.service.ServiceReference)
	 */
	@Override
	protected void commitTransaction(ServiceReference serviceRef) {
		// Do transaction success
		TransactionManager transactionManager = super.getTransactionManager();
		if (transactionManager != null) {
			transactionManager.commit();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.service.interceptor.impl.ServiceInterceptor#rollbackTransaction(org.umeframework.dora.service.ServiceReference, java.lang.Throwable)
	 */
	@Override
	protected void rollbackTransaction(ServiceReference serviceRef, Throwable e) {
		// Do transaction fail
		TransactionManager transactionManager = super.getTransactionManager();
		if (transactionManager != null) {
			transactionManager.rollback();
		}
	}

}
