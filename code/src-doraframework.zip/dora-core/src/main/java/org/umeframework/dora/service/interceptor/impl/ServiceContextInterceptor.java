package org.umeframework.dora.service.interceptor.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.service.BaseComponent;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;
import org.umeframework.dora.util.StringUtil;

/**
 * Service context intercept
 * 
 * @author Yue MA
 * 
 */
public class ServiceContextInterceptor extends BaseComponent implements Interceptor {

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.web.interceptor.Interceptor#intercept(tora.
     * fw.web.interceptor.InterceptorChain)
     */
    @Override
    public void intercept(
            InterceptorChain chain) throws Exception {
        SessionContext ctx = SessionContext.open();
        HttpServletRequest request = chain.getRequest();
        HttpServletResponse response = chain.getResponse();
    	try {
        	// Get common items into HTTP header
            String token = request.getHeader(SessionContext.Key.Token.toString());
            ctx.set(SessionContext.Key.Token, token);
            String uid = request.getHeader(SessionContext.Key.UID.toString());
            if (StringUtil.isEmpty(uid)) {
            	uid = request.getParameter(SessionContext.Key.UID.toString());
            }
            ctx.set(SessionContext.Key.UID, uid);
            
            // Do next intercept
    		chain.next();
    	} finally {
        	// Set common items into HTTP header
            response.addHeader(SessionContext.Key.UID.toString(), String.valueOf(ctx.get(SessionContext.Key.UID)));
            response.addHeader(SessionContext.Key.Token.toString(), String.valueOf(ctx.get(SessionContext.Key.Token)));
    	}
    }

}
