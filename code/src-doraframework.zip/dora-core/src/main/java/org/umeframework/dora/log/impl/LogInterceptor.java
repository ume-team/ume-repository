package org.umeframework.dora.log.impl;

import java.lang.reflect.Method;

import javax.annotation.Resource;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.umeframework.dora.log.Logger;

/**
 * Logger of method input params MethodInterceptor
 *
 * @author Yue MA
 */
@Deprecated
public class LogInterceptor implements MethodInterceptor {
	/**
	 * logger
	 */
	@Resource
	private Logger logger;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.aopalliance.intercept.MethodInterceptor#invoke(org.aopalliance.
	 * intercept.MethodInvocation)
	 */
	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {

		Method method = invocation.getMethod();
		Object[] params = invocation.getArguments();
		logger.debug(method.getName() + " Method Parameters:");
		for (Object param : params) {
			logger.debug(param);
		}

		return invocation.proceed();
	}

	/**
	 * @return the logger
	 */
	public Logger getLogger() {
		return logger;
	}

	/**
	 * @param logger
	 *            the logger to set
	 */
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}
