package org.umeframework.dora.service.mapping;

import java.util.Map;

import org.umeframework.dora.exception.ExceptionHandler;
import org.umeframework.dora.exception.SystemException;
import org.umeframework.dora.service.ServiceReference;
import org.umeframework.dora.service.ServiceResponse;
import org.umeframework.dora.transaction.TransactionManager;

/**
 * Service class and method naming rule identify interface
 * 
 * @author Yue MA
 * 
 */
public interface ServiceMapping {
    /**
     * getServiceReference
     * 
     * @param serviceId
     * @return
     */
    ServiceReference getServiceReference(
            String serviceId);
    
    /**
     * Run Service without transaction and exception handling
     * 
     * @param serviceId
     * @param methodParam
     * @return
     * @throws Throwable
     */
    ServiceResponse<Object> runService(
            String serviceId,
            Object[] methodParam) throws Throwable;
    
    /**
     * Run Web Service within transaction scope and exception handling
     * 
     * @param serviceId
     * @param methodParam
     * @param transactionManager
     * @param exceptionHandlers
     * @return
     * @throws Throwable
     */
    ServiceResponse<Object> runTransactionalService(
            String serviceId,
            Object[] methodParam, 
            TransactionManager transactionManager,
            Map<String, ExceptionHandler> exceptionHandlers);
    
    
    /**
     * addService
     * 
     * @param serviceId
     * @param serviceValue
     * @throws SystemException
     */
    void addService(
            String serviceId,
            String serviceValue) throws SystemException;
    
    /**
     * enableService
     * 
     * @param serviceId
     */
    void enableService(
            String serviceId);

    /**
     * disableService
     * 
     * @param serviceId
     */
    void disableService(
            String serviceId);

    /**
     * getEnableWebServices
     * 
     * @return
     */
    String[] getEnableServiceList();

    /**
     * getDisableWebServices
     * 
     * @return
     */
    String[] getDisableServiceList();
}
