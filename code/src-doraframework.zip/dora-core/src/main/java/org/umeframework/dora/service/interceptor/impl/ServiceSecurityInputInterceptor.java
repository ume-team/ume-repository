package org.umeframework.dora.service.interceptor.impl;

import org.umeframework.dora.security.Decryptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;

/**
 * Service security input parameter processor.<br>
 *
 * @author Yue MA
 */
public class ServiceSecurityInputInterceptor extends ServiceInputInterceptor {
	/**
	 * encrypt and decrypt util
	 */
	private Decryptor decryptor;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.web.interceptor.Interceptor#intercept(tora. fw.web.interceptor.InterceptorChain)
	 */
	@Override
	public void intercept(InterceptorChain chain) throws Exception {
		String inputData = chain.getJsonInputData();
		Object serviceParams = chain.getServiceParams();
		if (inputData != null && serviceParams == null) {
			if (decryptor != null) {
				inputData = decryptor.decrypt(inputData);
			}
		}
		super.intercept(chain);
	}

	/**
	 * @return the decryptor
	 */
	public Decryptor getDecryptor() {
		return decryptor;
	}

	/**
	 * @param decryptor the decryptor to set
	 */
	public void setDecryptor(Decryptor decryptor) {
		this.decryptor = decryptor;
	}
	
}
