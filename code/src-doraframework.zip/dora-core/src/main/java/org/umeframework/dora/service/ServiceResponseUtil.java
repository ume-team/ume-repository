package org.umeframework.dora.service;

import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.umeframework.dora.ajax.ParserException;
import org.umeframework.dora.ajax.impl.JSONParserImpl;

/**
 * Util class to access JSON text of service response.<br>
 * 
 * @author Yue MA
 *
 */
public abstract class ServiceResponseUtil {

	/**
	 * Get result code of ServiceResponse
	 * 
	 * @param jsonResponseText
	 * @return
	 */
	public static int getResultCodeFromJson(String jsonResponseText) {
		try {
			JSONObject joResponse = new JSONObject(jsonResponseText);

			int resultCode = joResponse.getInt("resultCode");
			return resultCode;
		} catch (JSONException e) {
			throw new ParserException("Fail to create JSONObject:" + jsonResponseText, e);
		}
	}

	/**
	 * Get result object of ServiceResponse
	 * 
	 * @param jsonResponseText
	 * @param resultObjectClazz
	 * @return
	 */
	public static <T> T getResultObjectFromJson(String jsonResponseText, Class<T> resultObjectClazz) {
		T resultObject = null;
		try {
			JSONObject joResponse = new JSONObject(jsonResponseText);

			int resultCode = joResponse.getInt("resultCode");
			if (ServiceResponse.SUCCESS == resultCode) {
				JSONObject joResultObject = joResponse.getJSONObject("resultObject");

				JSONParserImpl jsonParser = new JSONParserImpl();
				resultObject = jsonParser.parse(joResultObject.toString(), resultObjectClazz, null, null);
			}
		} catch (JSONException e) {
			throw new ParserException("Fail to create JSONObject:" + jsonResponseText + "," + resultObjectClazz, e);
		}
		return resultObject;
	}

}
