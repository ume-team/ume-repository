package org.umeframework.dora.service.user;

import org.umeframework.dora.service.UserEntity;

/**
 * User authentication interface declare.
 * 
 * @author mayue
 *
 */
public interface UserAuthenticator<E extends UserEntity> {

	/**
	 * Do authenticate by input login ID and password.<br>
	 * return non-empty UserObject instance (usually an child class inherit from UserObject) once authentication successful.<br>
	 * 
	 * @param loginId
	 *            - login ID
	 * @param loginPassword
	 *            - login password
	 * @return actual UserObject instance
	 */
	E getUserObject(String loginId, String loginPassword, String... options);

}
