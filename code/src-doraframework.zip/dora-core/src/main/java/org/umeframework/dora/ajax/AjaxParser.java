package org.umeframework.dora.ajax;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

/**
 * json data parse interface.<br>
 * 
 * @author Yue MA
 */
public interface AjaxParser<E> {
    /**
     * Parse json input data to java object
     * 
     * @param inData
     *            - input data
     * @param clazz
     *            - target java object type
     * @param genericType
     *            - target java object generic type
     * @param annotations
     *            - input param's annotations
     * 
     * @return - java object
     * @throws Exception
     */
    <T> T parse(
            E inData,
            Class<T> clazz,
            Type genericType,
            Annotation[] annotations) throws Exception;

}
