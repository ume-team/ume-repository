package org.umeframework.dora.validation.format;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Tag
 * 
 * @author Yue MA
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Tag {
    /**
     * value
     * 
     * @return
     */
    public String value();
}
