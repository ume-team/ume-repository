package org.umeframework.dora.type;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * DateConvert
 * 
 * @author Yue MA
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface DateConvert {
    /**
     * from
     * 
     * @return
     */
    public String from();

    /**
     * to
     * 
     * @return
     */
    public String to();
}
