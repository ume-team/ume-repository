package org.umeframework.dora.log.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.ThreadContext;
import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.log.Logger;

/**
 * Logger implement class
 *
 * @author Yue MA
 */
public class Log4j2Impl implements Logger {

	/**
	 * getAppender
	 * 
	 * @param name
	 * @return
	 */
	public org.apache.logging.log4j.Logger getAppender(String name) {
		org.apache.logging.log4j.Logger appender = LogManager.getLogger(name);
		return appender;
	}

	/**
	 * getAppender
	 * 
	 * @return
	 */
	public org.apache.logging.log4j.Logger getAppender() {
		return getAppender(this.getClass().getName());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#debug(java.lang.Object[])
	 */
	@Override
	public void debug(Object... messages) {
		if (messages != null && getAppender() != null) {
			StringBuilder message = new StringBuilder();
			for (Object e : messages) {
				message.append(e);
			}
			getAppender().debug(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#debug(java.lang.Object)
	 */
	public void debug(Object message) {
		if (getAppender() != null) {
			getAppender().debug(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#info(java.lang.Object[])
	 */
	@Override
	public void info(Object... messages) {
		if (messages != null && getAppender() != null) {
			StringBuilder message = new StringBuilder();
			for (Object e : messages) {
				message.append(e);
			}
			getAppender().info(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#info(java.lang.Object)
	 */
	public void info(Object message) {
		if (getAppender() != null) {
			getAppender().info(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.core.log.Logger#warn(java.lang.Object)
	 */
	@Override
	public void warn(Object message) {
		if (getAppender() != null) {
			getAppender().warn(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.core.log.Logger#warn(java.lang.Object, java.lang.Throwable)
	 */
	@Override
	public void warn(Object message, Throwable ex) {
		if (getAppender() != null) {
			getAppender().warn(buildMessage(String.valueOf(message) + "," + ex));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.core.log.Logger#error(java.lang.Object)
	 */
	@Override
	public void error(Object message) {
		if (getAppender() != null) {
			getAppender().error(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.core.log.Logger#error(java.lang.Object,
	 * java.lang.Throwable)
	 */
	@Override
	public void error(Object message, Throwable ex) {
		if (getAppender() != null) {
			getAppender().error(buildMessage(String.valueOf(message)), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.core.log.Logger#fatal(java.lang.Object)
	 */
	@Override
	public void fatal(Object message) {
		if (getAppender() != null) {
			getAppender().fatal(buildMessage(String.valueOf(message)));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.core.log.Logger#fatal(java.lang.Object,
	 * java.lang.Throwable)
	 */
	@Override
	public void fatal(Object message, Throwable ex) {
		if (getAppender() != null) {
			getAppender().fatal(buildMessage(String.valueOf(message)), ex);
		}
	}

	/**
	 * Build append log parameters base on session context properties.<br>
	 * 
	 * @param message
	 * @return
	 */
	protected String buildMessage(String message) {
		SessionContext ctx = SessionContext.open();
		String client = ctx.get(SessionContext.Key.RequestHost);
		String system = ctx.get(SessionContext.Key.SysId);
		String service = ctx.get(SessionContext.Key.ServiceId);
		String uid = ctx.get(SessionContext.Key.UID);
		String thread = String.valueOf(Thread.currentThread().getId());

		client = client != null ? client : "";
		system = system != null ? system : "";
		service = service != null ? service : "";
		uid = uid != null ? uid : "";

		ThreadContext.put("thread", thread);
		ThreadContext.put("system", system);
		ThreadContext.put("service", service);
		ThreadContext.put("client", client);
		ThreadContext.put("user", uid);

		return message;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#isDebugEnabled()
	 */
	@Override
	public boolean isDebugEnabled() {
		return getAppender().isDebugEnabled();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#isInfoEnabled()
	 */
	@Override
	public boolean isInfoEnabled() {
		return getAppender().isInfoEnabled();
	}

}
