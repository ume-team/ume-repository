package org.umeframework.dora.service.interceptor.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.exception.AuthenticationException;
import org.umeframework.dora.exception.TimeoutException;
import org.umeframework.dora.property.ConfigProperties;
import org.umeframework.dora.service.BaseComponent;
import org.umeframework.dora.service.ServiceReference;
import org.umeframework.dora.service.UserEntity;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;
import org.umeframework.dora.service.mapping.ServiceMapping;
import org.umeframework.dora.service.user.UserAccessValidator;
import org.umeframework.dora.service.user.UserLoginService;
import org.umeframework.dora.util.CodecUtil;
import org.umeframework.dora.util.StringUtil;

/**
 * Service authenticate intercept.<br>
 *
 * @author Yue MA
 */
public class ServiceAuthenticateInterceptor extends BaseComponent implements Interceptor {
	/**
	 * Web Service initialize manager
	 */
	@Resource(name = "serviceMapping")
	private ServiceMapping serviceMapping;
	/**
	 * User cache service instance
	 */
	@Resource(name = "userLoginService")
	private UserLoginService userLoginService;
	/**
	 * User access control resource checker
	 */
	private UserAccessValidator<UserEntity> userAccessValidator;
	/**
	 * Token will pass by client for authenticate
	 */
	private boolean enableTokenClient = true;
	/**
	 * Token will store in http session, enableTokenClient is prefer while both enableTokenClient and enableTokenSession were true
	 */
	private boolean enableTokenSession = true;
	/**
	 * Token expire time, 0 mean never expired, unit is second
	 */
	private long tokenExpire = 604800;
	/**
	 * Token refresh interval second, 0 mean never change
	 */
	private long tokenRefreshInterval = 0;
	/**
	 * serviceWhiteListConfigProperties
	 */
	private ConfigProperties serviceWhiteListConfigProperties;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.interceptor.Interceptor#intercept(org.umeframework.dora.interceptor. InterceptorChain)
	 */
	@Override
	public void intercept(InterceptorChain chain) throws Exception {
		if (serviceWhiteListConfigProperties != null) {
			// check white list if serviceWhiteListConfigProperties was provided
			checkAccessibleAddress(chain.getRequest().getRemoteAddr(), chain.getSysId(), chain.getServiceId());
		}
		if (userLoginService == null) {
			// serviceAuthenticateProperties and userCacheService instance must
			// provide for this intercept
			throw new AuthenticationException("Authentication failed: login service was not setup.");
		}
		// start context
		Timestamp curremtTime = super.getCurrentTimestamp();

		SessionContext ctx = SessionContext.open();

		// get session if exist
		HttpSession session = chain.getRequest().getSession(false);
		String serviceId = chain.getServiceId();
		String uid = null;
		String token = null;
		ServiceReference serviceProxy = serviceMapping.getServiceReference(serviceId);

		if (serviceProxy == null) {
			throw new AuthenticationException("Authentication failed: service is unavailable " + serviceId);
		}
		if (!serviceProxy.isAuthenticate() && session == null) {
			// create HttpSession when service is non-authentication (first time access after open browse usually)
			session = chain.getRequest().getSession();
			ctx.set(SessionContext.Key.HttpSession, session);
			getLogger().debug("Create new session for non-authenticated service.");
		}

		if (enableTokenClient) {
			// prefer use token pass from header when enableTokenClient
			token = chain.getRequest().getHeader(SessionContext.Key.Token.toString());
			if (StringUtil.isEmpty(token)) {
				// try use token pass from parameter when no token in header
				token = chain.getRequest().getParameter(SessionContext.Key.Token.toString());
			}
		}
		if (enableTokenSession && StringUtil.isEmpty(token) && session != null) {
			// try use token pass from session store when enableTokenSession
			token = String.valueOf(session.getAttribute(SessionContext.Key.Token.toString()));
		}
		if (StringUtil.isEmpty(token)) {
			throw new AuthenticationException("Authentication failed: current access was not authorized.");
		}

		try {
			if (serviceProxy.isAuthenticate()) {
				UserEntity userObj = userLoginService.getUserObject(token);
				if (userObj == null) {
					throw new AuthenticationException("Authentication failed: current user was not authorized.");
				}
				if (userAccessValidator != null && !userAccessValidator.isValid(userObj, token, chain.getSysId(), chain.getServiceId())) {
					throw new AuthenticationException("Authentication failed: User access validation error.");
				}

				uid = userObj.getUid();
				long timeInterval = curremtTime.getTime() - userObj.getLastTransactionTime().getTime();
				if (timeInterval != 0 && timeInterval > tokenExpire * 1000) {
					getLogger().warn("Token expired of " + uid);
					userLoginService.deleteUserObject(token);
					throw new TimeoutException("Login expired.");
				}

				userObj.setLastTransactionTime(curremtTime);
				if (tokenRefreshInterval != 0 && timeInterval > tokenRefreshInterval * 1000) {
					// change token while enableTokenDynamic flag was set and timeInterval great than 5 sec
					synchronized (userLoginService) {
						// dynamic change token value after authenticate successful
						String oldToken = token;
						token = CodecUtil.encodeMD5Hex(oldToken + System.currentTimeMillis());
						userLoginService.renewUserObject(oldToken, token, userObj);
					}
				} else {
					userLoginService.setUserObject(token, userObj);
				}

			}
			// set append common items in context
			ctx.set(SessionContext.Key.Token, token);
			ctx.set(SessionContext.Key.UID, uid);
			// do normal process
			chain.next();

		} finally {
			// Response common items into HTTP header
			if (!serviceProxy.isAuthenticate()) {
				// must get token again because login service could create new token and store in context
				token = ctx.get(SessionContext.Key.Token);
			}
			if (enableTokenClient) {
				chain.getResponse().addHeader(SessionContext.Key.Token.toString(), token);
			}
			if (enableTokenSession && session != null) {
				session.setAttribute(SessionContext.Key.Token.toString(), token);
			}
		}
	}

	/**
	 * Check accessible client address
	 * 
	 * @param address
	 * @param sysId
	 * @param serviceId
	 * @throws AuthenticationException
	 */
	protected void checkAccessibleAddress(String address, String sysId, String serviceId) throws AuthenticationException {
		String config = serviceWhiteListConfigProperties.get(address);
		if (!StringUtil.isEmpty(config)) {
			throw new AuthenticationException("Prohibit access error: address " + address + " is invalid.");
		}
		if (!config.equalsIgnoreCase("true") && !config.equals("*")) {
			config = config.contains("|") ? config.replace("|", ",") : config;
			String[] values = config.contains(",") ? config.split(",") : new String[] { config };
			List<String> availableServices = new ArrayList<String>();
			for (String value : values) {
				availableServices.add(value);
			}
			if (!availableServices.contains(serviceId)) {
				throw new AuthenticationException("Prohibit access error: address " + address + " is invalid.");
			}
		}
	}

	/**
	 * @return the userLoginService
	 */
	public UserLoginService getUserLoginService() {
		return userLoginService;
	}

	/**
	 * @param userLoginService
	 *            the userLoginService to set
	 */
	public void setUserLoginService(UserLoginService userLoginService) {
		this.userLoginService = userLoginService;
	}

	/**
	 * @return the enableTokenClient
	 */
	public boolean isEnableTokenClient() {
		return enableTokenClient;
	}

	/**
	 * @param enableTokenClient
	 *            the enableTokenClient to set
	 */
	public void setEnableTokenClient(boolean enableTokenClient) {
		this.enableTokenClient = enableTokenClient;
	}

	/**
	 * @return the tokenExpire
	 */
	public long getTokenExpire() {
		return tokenExpire;
	}

	/**
	 * @param tokenExpire
	 *            the tokenExpire to set
	 */
	public void setTokenExpire(long tokenExpire) {
		this.tokenExpire = tokenExpire;
	}

	/**
	 * @return the userAccessValidator
	 */
	public UserAccessValidator<UserEntity> getUserAccessValidator() {
		return userAccessValidator;
	}

	/**
	 * @param userAccessValidator
	 *            the userAccessValidator to set
	 */
	public void setUserAccessValidator(UserAccessValidator<UserEntity> userAccessValidator) {
		this.userAccessValidator = userAccessValidator;
	}

	/**
	 * @return the tokenRefreshInterval
	 */
	public long getTokenRefreshInterval() {
		return tokenRefreshInterval;
	}

	/**
	 * @param tokenRefreshInterval
	 *            the tokenRefreshInterval to set
	 */
	public void setTokenRefreshInterval(long tokenRefreshInterval) {
		this.tokenRefreshInterval = tokenRefreshInterval;
	}

	/**
	 * @return the enableTokenSession
	 */
	public boolean isEnableTokenSession() {
		return enableTokenSession;
	}

	/**
	 * @param enableTokenSession
	 *            the enableTokenSession to set
	 */
	public void setEnableTokenSession(boolean enableTokenSession) {
		this.enableTokenSession = enableTokenSession;
	}

	/**
	 * @return the serviceWhiteListConfigProperties
	 */
	public ConfigProperties getServiceWhiteListConfigProperties() {
		return serviceWhiteListConfigProperties;
	}

	/**
	 * @param serviceWhiteListConfigProperties
	 *            the serviceWhiteListConfigProperties to set
	 */
	public void setServiceWhiteListConfigProperties(ConfigProperties serviceWhiteListConfigProperties) {
		this.serviceWhiteListConfigProperties = serviceWhiteListConfigProperties;
	}

	/**
	 * @return the serviceMapping
	 */
	public ServiceMapping getServiceMapping() {
		return serviceMapping;
	}

	/**
	 * @param serviceMapping
	 *            the serviceMapping to set
	 */
	public void setServiceMapping(ServiceMapping serviceMapping) {
		this.serviceMapping = serviceMapping;
	}

}
