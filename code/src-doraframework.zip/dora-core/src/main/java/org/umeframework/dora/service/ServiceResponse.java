package org.umeframework.dora.service;

/**
 * Base service response object structure define
 * 
 * @author Yue MA
 */
public class ServiceResponse<T> extends BaseServiceResponse<T> implements java.io.Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -9075476354638484508L;

	/**
	 * Service execute result object
	 */
	private T resultObject;
	/**
	 * getResultObject
	 * 
	 * @return
	 */
	public T getResultObject() {
		return resultObject;
	}
	/**
	 * setResultObject
	 * 
	 * @param
	 */
	public void setResultObject(T resultObject) {
		this.resultObject = resultObject;
	}
}
