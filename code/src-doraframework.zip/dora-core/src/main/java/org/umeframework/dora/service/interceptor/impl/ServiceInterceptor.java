package org.umeframework.dora.service.interceptor.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import javax.annotation.Resource;

import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.exception.TransactionException;
import org.umeframework.dora.service.BaseComponent;
import org.umeframework.dora.service.ServiceReference;
import org.umeframework.dora.service.ServiceResponse;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;
import org.umeframework.dora.service.mapping.ServiceMapping;
import org.umeframework.dora.transaction.TransactionManager;
import org.umeframework.dora.transaction.TransactionRequired;

/**
 * ServiceInterceptor
 *
 * @author Yue MA
 *
 */
public class ServiceInterceptor extends BaseComponent implements Interceptor {
	/**
	 * Web Service initialize information handler
	 */
	@Resource(name = "serviceMapping")
	private ServiceMapping serviceMapping;
	/**
	 * transaction manager
	 */
	@Resource(name = "transactionManager")
	private TransactionManager transactionManager;

	/*
	 * (non-Javadoc)
	 *
	 * @see org.umeframework.dora.web.interceptor.Interceptor#intercept(tora. fw.web.interceptor.InterceptorChain)
	 */
	@Override
	public void intercept(InterceptorChain chain) throws Throwable {
		getLogger().debug("Service starting...");
		String serviceId = chain.getServiceId();
		Object[] serviceParams = chain.getServiceParams();

		ServiceReference serviceRef = serviceMapping.getServiceReference(serviceId);
		if (serviceRef == null) {
			throw new RuntimeException("No find service " + serviceId);
		}

		ServiceResponse<Object> serviceResponse = new ServiceResponse<Object>();
		try {
			beginTransaction(serviceRef);

			Object resultObj = serviceRef.execute(serviceParams);
			serviceResponse.setResultCode(ServiceResponse.SUCCESS);
			serviceResponse.setResultObject(resultObj);

			commitTransaction(serviceRef);
			getLogger().debug("Service completed.");
		} catch (Throwable e) {
			rollbackTransaction(serviceRef, e);

			if (e instanceof InvocationTargetException) {
				e = ((InvocationTargetException) e).getTargetException();
			}
			throw e;
		} finally {
			try {
				List<String> messages = SessionContext.open().getMessages();
				if (messages != null) {
					for (String e : messages) {
						serviceResponse.addMessage(e);
					}
				}
			} catch (Throwable e) {
				throw e;
			}
			chain.setServiceResponse(serviceResponse);
			chain.next();
		}
	}

	/**
	 * beginTransaction
	 * 
	 * @param serviceRef
	 */
	protected void beginTransaction(ServiceReference serviceRef) {
		if (serviceRef.isTransactional() && transactionManager != null) {
			// Do transaction begin
			transactionManager.begin();
		}
	}

	/**
	 * commitTransaction
	 * 
	 * @param serviceRef
	 */
	protected void commitTransaction(ServiceReference serviceRef) {
		if (serviceRef.isTransactional() && transactionManager != null) {
			// Do transaction success
			transactionManager.commit();
		}
	}

	/**
	 * rollbackTransaction
	 * 
	 * @param serviceRef
	 * @param e
	 */
	protected void rollbackTransaction(ServiceReference serviceRef, Throwable e) {
		if (serviceRef.isTransactional() && !(e instanceof TransactionException) && transactionManager != null) {
			// Do transaction fail
			transactionManager.rollback();
		}
	}

	/**
	 * Is transaction required
	 * 
	 * @param serviceMethod
	 * @return
	 */
	protected boolean requireTransaction(Method serviceMethod) {
		TransactionRequired tx = serviceMethod.getAnnotation(TransactionRequired.class);
		return tx != null;
	}

	/**
	 * @return the transactionManager
	 */
	public TransactionManager getTransactionManager() {
		return transactionManager;
	}

	/**
	 * @param transactionManager
	 *            the transactionManager to set
	 */
	public void setTransactionManager(TransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	/**
	 * @return the serviceMapping
	 */
	public ServiceMapping getServiceMapping() {
		return serviceMapping;
	}

	/**
	 * @param serviceMapping
	 *            the serviceMapping to set
	 */
	public void setServiceMapping(ServiceMapping serviceMapping) {
		this.serviceMapping = serviceMapping;
	}

}
