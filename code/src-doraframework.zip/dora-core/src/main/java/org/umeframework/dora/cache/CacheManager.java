package org.umeframework.dora.cache;

/**
 * CacheManager
 *
 * @author Yue MA
 */
public interface CacheManager {
    /**
     * set object to cache
     *
     * @param key
     * @param value
     * @return
     */
    <E> long set(
            String key,
            E value);

    /**
     * set object to cache
     *
     * @param key
     * @param expire
     * @param value
     */
    long set(
            String key,
            int expire,
            Object value);

    /**
     * Get object instances from cache
     *
     * @param key
     * @return
     */
    <E> E get(
            String key);

    /**
     * Remove object instances from cache
     *
     * @param key
     * @return
     */
    long remove(
            String key);

    /**
     * init
     */
    void init();

    /**
     * shutdown
     */
    void shutdown();
}
