package org.umeframework.dora.service.interceptor.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.umeframework.dora.ajax.AjaxRender;
import org.umeframework.dora.exception.ExceptionHandler;
import org.umeframework.dora.exception.ServcieRetryException;
import org.umeframework.dora.service.ServiceResponse;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;

/**
 * DefaultInterceptorChain
 *
 * @author Yue MA
 */
public class DefaultInterceptorChain implements InterceptorChain {
    /**
     * exception handler map
     */
    @Resource(name="exceptionHandler")
    private ExceptionHandler exceptionHandler;

    /**
     * ajax render
     */
    @Resource(name="ajaxRender")
    private AjaxRender<String> ajaxRender;
    /**
     * intercept list
     */
    private List<Interceptor> interceptorList;
    
    /**
     * intercept count
     */
    private int count = -1;
    /**
     * sys id
     */
    private String sysId;
    /**
     * context
     */
    private ServletContext context;
    /**
     * locale
     */
    private Locale locale;
    /**
     * HTTP request
     */
    private HttpServletRequest request;
    /**
     * HTTP response
     */
    private HttpServletResponse response;
    /**
     * service id
     */
    private String serviceId;
    /**
     * service input parameters
     */
    private Object[] serviceInput;
    /**
     * service out response
     */
    private ServiceResponse<Object> serviceResponse;
    /**
     * input data
     */
    private String jsonInputData;
    /**
     * output data
     */
    private String jsonOutputData;

    /**
     * expected exception caught flag
     */
    private boolean caughtExpectedException;
    /**
     * exception processed flag
     */
    private boolean isProcessedException;

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#next()
     */
    @Override
    public void next() {
        count++;
        if (count >= interceptorList.size()) {
            return;
        }
        try {
            Interceptor interceptor = interceptorList.get(count);
            interceptor.intercept(this);
        } catch (Throwable cause) {
            // get actual exception instance
            while (cause.getClass().equals(InvocationTargetException.class)) {
                cause = ((InvocationTargetException) cause).getTargetException();
            }
            if (cause instanceof ServcieRetryException) {
                isProcessedException = true;
                throw (ServcieRetryException) cause;
            }

            if (isProcessedException) {
                return;
            }

            if (serviceResponse == null) {
                // create CommonServiceResponse for save exception information
                serviceResponse = new ServiceResponse<Object>();
            }
            
            if (exceptionHandler != null) {
            	exceptionHandler.handleException(serviceResponse, cause);
            }

            // render exception message to JSON
            String jsonOutputData = ajaxRender.render(this.getServiceResponse());
            this.setJsonOutputData(jsonOutputData);
            isProcessedException = true;

            return;
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setContext(javax.servlet
     * .ServletContext)
     */
    public void setContext(
            ServletContext context) {
        this.context = context;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setInterceptorList(java
     * .util.List)
     */
    public void setInterceptorList(
            List<Interceptor> interceptorList) {
        this.interceptorList = interceptorList;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setLocale(java.util.
     * Locale)
     */
    @Override
    public void setLocale(
            Locale locale) {
        this.locale = locale;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setRequest(javax.servlet
     * .http.HttpServletRequest)
     */
    @Override
    public void setRequest(
            HttpServletRequest request) {
        this.request = request;

    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setResponse(javax.servlet
     * .http.HttpServletResponse)
     */
    @Override
    public void setResponse(
            HttpServletResponse response) {
        this.response = response;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getContext()
     */
    @Override
    public ServletContext getContext() {
        return context;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getLocale()
     */
    @Override
    public Locale getLocale() {
        return locale;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getRequest()
     */
    @Override
    public HttpServletRequest getRequest() {
        return request;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getResponse()
     */
    @Override
    public HttpServletResponse getResponse() {
        return response;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getServiceId()
     */
    public String getServiceId() {
        return serviceId;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setServiceId(java.lang
     * .String)
     */
    public void setServiceId(
            String serviceId) {
        this.serviceId = serviceId;
    }

    /* (non-Javadoc)
     * @see org.umeframework.dora.interceptor.InterceptorChain#getInputData()
     */
    public String getJsonInputData() {
        return jsonInputData;
    }

    /* (non-Javadoc)
     * @see org.umeframework.dora.interceptor.InterceptorChain#setInputData(java.lang.String)
     */
    public void setJsonInputData(
            String inputData) {
        this.jsonInputData = inputData;
    }
    /* (non-Javadoc)
     * @see org.umeframework.dora.interceptor.InterceptorChain#getOutputData()
     */
    public String getJsonOutputData() {
        return jsonOutputData;
    }

    /* (non-Javadoc)
     * @see org.umeframework.dora.interceptor.InterceptorChain#setOutputData(java.lang.String)
     */
    public void setJsonOutputData(
            String outputData) {
        this.jsonOutputData = outputData;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getInterceptorList()
     */
    public List<Interceptor> getInterceptorList() {
        return interceptorList;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getServiceInput()
     */
    public Object[] getServiceParams() {
        return serviceInput;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setServiceInput(java
     * .lang.Object)
     */
    public void setServiceParams(
            Object[] serviceInput) {
        this.serviceInput = serviceInput;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#getServiceOutput()
     */
    public ServiceResponse<Object> getServiceResponse() {
        return serviceResponse;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.web.interceptor.InterceptorChain#setServiceOutput(com
     * .ibm.org.umeframework.dora.core.service.ServiceResponse)
     */
    public void setServiceResponse(
            ServiceResponse<Object> serviceOutput) {
        this.serviceResponse = serviceOutput;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.core.interceptor.InterceptorChain#getSysId()
     */
    @Override
    public String getSysId() {
        return sysId;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.core.interceptor.InterceptorChain#setSysId(java.lang.
     * String)
     */
    @Override
    public void setSysId(
            String sysId) {
        this.sysId = sysId;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.core.interceptor.InterceptorChain#getAjaxRender()
     */
    public AjaxRender<String> getAjaxRender() {
        return ajaxRender;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * org.umeframework.dora.interceptor.InterceptorChain#setAjaxRender(org.umeframework.dora.ajax.AjaxRender
     * )
     */
    public void setAjaxRender(
            AjaxRender<String> ajaxRender) {
        this.ajaxRender = ajaxRender;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.interceptor.InterceptorChain#isCaughtExpectedException()
     */
    public boolean getCaughtExpectedException() {
        return caughtExpectedException;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.umeframework.dora.interceptor.InterceptorChain#setCaughtExpectedException
     * (boolean)
     */
    public void setCaughtExpectedException(
            boolean caughtExpectedException) {
        this.caughtExpectedException = caughtExpectedException;
    }

	/**
	 * @return the exceptionHandler
	 */
	public ExceptionHandler getExceptionHandler() {
		return exceptionHandler;
	}

	/**
	 * @param exceptionHandler the exceptionHandler to set
	 */
	public void setExceptionHandler(ExceptionHandler exceptionHandler) {
		this.exceptionHandler = exceptionHandler;
	}

}
