package org.umeframework.dora.security;

/**
 * Encryptor
 * 
 * @author mmayye
 * 
 *
 */
public interface Encryptor {
	/**
	 * encrypt
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	String encrypt(
            String data) throws Exception;
}
