package org.umeframework.dora.log.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.log4j.MDC;
import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.log.Logger;

/**
 * Logger implement class
 *
 * @author Yue MA
 */
@Deprecated
public class LoggerImpl implements Logger {
    /**
     * LOG4J instance
     */
    private org.apache.log4j.Logger appender;

    /**
     * Max length of log message while print to database
     */
    private int messageMaxLenth = 1024;
    
    /**
     * Host name in log style
     * 0 - no show
     * 1 - show as ip address
     * 2 - show as host name
     */
    private int showHostName = 0;

	/**
     * LoggerImpl
     */
    public LoggerImpl() {
        this.appender = org.apache.log4j.Logger.getLogger("applog");
    }

    /**
     * LoggerImpl
     *
     * @param appender
     */
    public LoggerImpl(
            String appender) {
        this.appender = org.apache.log4j.Logger.getLogger(appender);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.log.Logger#debug(java.lang.Object[])
     */
    @Override
    public void debug(
            Object... messages) {
        if (getAppender().isDebugEnabled() && messages != null) {
            StringBuilder message = new StringBuilder();
            for (Object e : messages) {
                message.append(e);
                message.append(' ');
            }
            getAppender().debug(buildMessage(String.valueOf(message)));
        }
    }
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#debug(java.lang.Object)
	 */
	public void debug(Object message) {
		if (getAppender().isDebugEnabled()) {
			getAppender().debug(buildMessage(String.valueOf(message)));
		}
	}

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.log.Logger#info(java.lang.Object[])
     */
    @Override
    public void info(
            Object... messages) {
        if (getAppender().isInfoEnabled() && messages != null) {
            StringBuilder message = new StringBuilder();
            for (Object e : messages) {
                message.append(e);
                message.append(' ');
            }
            getAppender().info(buildMessage(String.valueOf(message)));
        }

    }
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.log.Logger#debug(java.lang.Object)
	 */
	public void info(Object message) {
		if (getAppender().isInfoEnabled()) {
			getAppender().info(buildMessage(String.valueOf(message)));
		}
	}

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.log.Logger#warn(java.lang.Object)
     */
    @Override
    public void warn(
            Object message) {
        getAppender().warn(buildMessage(String.valueOf(message)));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.log.Logger#warn(java.lang.Object, java.lang.Throwable)
     */
    @Override
    public void warn(
            Object message,
            Throwable ex) {
        getAppender().warn(buildMessage(String.valueOf(message) + "," + ex));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.log.Logger#error(java.lang.Object)
     */
    @Override
    public void error(
            Object message) {
        getAppender().error(buildMessage(String.valueOf(message)));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.log.Logger#error(java.lang.Object, java.lang.Throwable)
     */
    @Override
    public void error(
            Object message,
            Throwable ex) {
        getAppender().error(buildMessage(String.valueOf(message) + "," + ex), ex);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.log.Logger#fatal(java.lang.Object)
     */
    @Override
    public void fatal(
            Object message) {
        getAppender().fatal(buildMessage(String.valueOf(message)));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.core.log.Logger#fatal(java.lang.Object, java.lang.Throwable)
     */
    @Override
    public void fatal(
            Object message,
            Throwable ex) {
        getAppender().fatal(buildMessage(String.valueOf(message) + "," + ex), ex);
    }

    /**
     * append common message for log
     *
     * @param message
     * @return
     */
    protected String buildMessage(
            String message) {
        SessionContext ctx = SessionContext.open();
        String client = ctx.get(SessionContext.Key.RequestHost);
        String system = ctx.get(SessionContext.Key.SysId);
        String service = ctx.get(SessionContext.Key.ServiceId);
        String user = ctx.get(SessionContext.Key.UID);
        long thread = Thread.currentThread().getId();

        client = client != null ? client : "";
        system = system != null ? system : "";
        service = service != null ? service : "";
        user = user != null ? user : "";

        String host = "";
        try {
            if (showHostName == 1) {
            	host = InetAddress.getLocalHost().getHostAddress();
            } else if (showHostName == 2) {
            	host = InetAddress.getLocalHost().getHostName();
            }
        } catch (UnknownHostException e) {
        	host = "name-error";
        }
        MDC.put("host", host);
        MDC.put("user", user);
        MDC.put("client", client);
        MDC.put("thread", thread);
        MDC.put("system", system);
        MDC.put("service", service);

        String msgForSQL = message;
        // process message for insert into database by logger
        if (msgForSQL.contains("'")) {
            msgForSQL = msgForSQL.replace("\'", "\\\'");
        }
        if (msgForSQL.length() > messageMaxLenth) {
            msgForSQL = msgForSQL.substring(0, messageMaxLenth) + "...";
        }
        MDC.put("msg", msgForSQL);
        return message;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.log.Logger#isDebugEnabled()
     */
    @Override
    public boolean isDebugEnabled() {
        return getAppender().isDebugEnabled();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.umeframework.dora.log.Logger#isInfoEnabled()
     */
    @Override
    public boolean isInfoEnabled() {
        return getAppender().isInfoEnabled();
    }

    /**
     * @return the messageMaxLenth
     */
    public int getMessageMaxLenth() {
        return messageMaxLenth;
    }

    /**
     * @param messageMaxLenth
     *            the messageMaxLenth to set
     */
    public void setMessageMaxLenth(
            int messageMaxLenth) {
        this.messageMaxLenth = messageMaxLenth;
    }

    /**
     * @return the appender
     */
    public org.apache.log4j.Logger getAppender() {
        return appender;
    }

    /**
     * @param appender
     *            the appender to set
     */
    public void setAppender(
            org.apache.log4j.Logger appender) {
        this.appender = appender;
    }

	/**
	 * @return the showHostName
	 */
	public int getShowHostName() {
		return showHostName;
	}

	/**
	 * @param showHostName the showHostName to set
	 */
	public void setShowHostName(int showHostName) {
		this.showHostName = showHostName;
	}

}
