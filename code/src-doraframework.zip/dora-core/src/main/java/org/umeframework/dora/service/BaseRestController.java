package org.umeframework.dora.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.sql.Timestamp;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.umeframework.dora.bean.BeanFactory;
import org.umeframework.dora.context.SessionContext;
import org.umeframework.dora.exception.ServcieRetryException;
import org.umeframework.dora.service.interceptor.InterceptorChain;

/**
 * Entry rest controller implementation.<br>
 *
 * @author Yue MA
 */
public abstract class BaseRestController extends BaseComponent {
	/**
	 * Default bean factory instance.
	 */
	@Resource(name = "beanFactory")
	private BeanFactory beanFactory;

	/**
	 * Default intercept chain name
	 */
	private String defaultInterceptorChainName = "sys";

	/**
	 * execute HTTP request by the defined service intercept chains.
	 * 
	 * @param request
	 * @param response
	 * @param system
	 * @param serviceId
	 * @param jsonInput
	 * @param urlCharset
	 * @param urlCharset
	 * @param interceptorChainName
	 */
	public String execute(
	        String requestCategory,
	        HttpServletRequest request,
	        HttpServletResponse response,
	        String system,
	        String serviceId,
	        String jsonInput,
	        String interceptorChainName,
	        PrintWriter printWriter) {

		String jsonOutput = null;
		try {
			InterceptorChain chain = startServiceInterceptorChain(requestCategory, request, response, system, serviceId, jsonInput, interceptorChainName);

			if (chain != null) {
				ServiceResponse<Object> serviceResponse = chain.getServiceResponse();
				if (serviceResponse != null
				        && serviceResponse.getResultObject() != null
				        && serviceResponse.getResultObject() instanceof FileDownloadEntity) {
					// In case of file download
					FileDownloadEntity fileDownloadObject = (FileDownloadEntity) serviceResponse.getResultObject();
					doDownload(request, response, fileDownloadObject);
				} else {
					// In case of Json text return
					jsonOutput = chain.getJsonOutputData();
					printWriter.write(jsonOutput);
				}
			}
		} finally {
			printWriter.flush();
			printWriter.close();
		}
		return null;
	}

	/**
	 * Download file
	 * 
	 * @param request
	 * @param response
	 * @param fileDownloadObject
	 */
	protected void doDownload(HttpServletRequest request, HttpServletResponse response, FileDownloadEntity fileDownloadObject) {

		InputStream inputStream = null;
		OutputStream outputStream = null;
		try {
			String fileName = fileDownloadObject.getFileName();
			File file = null;
			if (fileDownloadObject.isInternalResource()) {
				ClassLoader classloader = Thread.currentThread().getContextClassLoader();
				file = new File(classloader.getResource(fileName).getFile());
			} else {
				file = new File(fileName);
			}
			if (file.exists()) {
				String downloadName = fileDownloadObject.getDownloadName();
				response.reset();
				response.setHeader("Content-Disposition", "attachment;fileName=" + downloadName);
				response.setContentType(fileDownloadObject.getContentType());
				response.setCharacterEncoding(fileDownloadObject.getCharacterEncoding());
				inputStream = new FileInputStream(file);
				outputStream = response.getOutputStream();
				byte[] buffer = new byte[2048];
				int length;
				while ((length = inputStream.read(buffer)) > 0) {
					outputStream.write(buffer, 0, length);
				}
			} else {
				getLogger().warn("Download file is not exist, " + fileDownloadObject.getFileName());
			}
		} catch (IOException e) {
			getLogger().error("Error in download file " + fileDownloadObject.getFileName(), e);
			throw new RuntimeException("Error in download file " + fileDownloadObject.getFileName(), e);
		} finally {
			try {
				if (outputStream != null) {
					outputStream.close();
				}
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (IOException e) {
				getLogger().error("Error in download file " + fileDownloadObject.getFileName(), e);
				throw new RuntimeException("Error in download file " + fileDownloadObject.getFileName(), e);
			}
		}
	}

	/**
	 * common service intercept process
	 *
	 * @param requestCategory
	 * @param request
	 * @param response
	 * @param systemId
	 * @param serviceId
	 * @param jsonInput
	 * @param interceptorChainName
	 * @return
	 */
	protected InterceptorChain startServiceInterceptorChain(
	        String requestCategory,
	        HttpServletRequest request,
	        HttpServletResponse response,
	        String systemId,
	        String serviceId,
	        String jsonInput,
	        String interceptorChainName) {
		SessionContext ctx = SessionContext.open();
		// Get common info from request and put in session context
		String appRootPath = request.getContextPath();
		ctx.set(SessionContext.Key.AppRootPath, appRootPath);
		String remoteAddr = request.getHeader("x-forwarded-for") == null ? request.getRemoteAddr() : request.getHeader("x-forwarded-for");
		ctx.set(SessionContext.Key.RequestHost, remoteAddr);
		ctx.set(SessionContext.Key.TransactionTime, new Timestamp(System.currentTimeMillis()));
		ctx.set(SessionContext.Key.RequestCategory, requestCategory);
		ctx.set(SessionContext.Key.SysId, systemId);
		ctx.set(SessionContext.Key.ServiceId, serviceId);

		// Write application log
		long startTime = System.currentTimeMillis();
		String jsonOutput = "";
		InterceptorChain chain = null;
		try {
			chain = (InterceptorChain) beanFactory.getBean(interceptorChainName);
		} catch (NoSuchBeanDefinitionException e) {
			chain = (InterceptorChain) beanFactory.getBean(defaultInterceptorChainName);
			getLogger().debug("No specified InterceptorChain for current system, use defult chain.");
		} catch (Exception e) {
			getLogger().error("No found interceptor:" + interceptorChainName, e);
		}
		if (chain == null) {
			getLogger().error("No found interceptor:" + interceptorChainName);
			return null;
		}

		chain.setRequest(request);
		chain.setResponse(response);
		chain.setSysId(systemId);
		chain.setServiceId(serviceId);
		chain.setJsonInputData(jsonInput);

		try {
			chain.next();
			jsonOutput = chain.getJsonOutputData();
		} catch (ServcieRetryException retryException) {
			try {
				int interal = retryException.getRetryInterval();
				int maxTime = retryException.getRetryMaxTime();
				serviceId = retryException.getRetryServiceId() == null ? serviceId : retryException.getRetryServiceId();

				for (int i = 1; i <= maxTime; i++) {
					try {
						retryException.setRetryIndex(retryException.getRetryIndex() + 1);
						getLogger().warn("Restart service: " + serviceId + " round " + retryException.getRetryIndex());
						Thread.sleep(interal);
						ctx.set(SessionContext.Key.RetryException, retryException);

						chain.setServiceId(retryException.getRetryServiceId());
						chain.setJsonInputData(jsonInput);
						chain.next();
						jsonOutput = chain.getJsonOutputData();
						ctx.remove(SessionContext.Key.RetryException);
						getLogger().warn("Restart service: " + serviceId + " round " + retryException.getRetryIndex() + " successful.");
						break;
					} catch (ServcieRetryException e) {
						// do next loop when met same ServcieRetryException
						// errors.
						ctx.set(SessionContext.Key.RetryException, e);
						getLogger().warn("Restart service: " + serviceId + " round " + retryException.getRetryIndex() + " failed.");
					}
				}
			} catch (Throwable e) {
				getLogger().error("Servcie retry error:" + serviceId, e);
				throw new RuntimeException("Servcie retry error:" + serviceId, e);
			}
		} catch (Throwable e) {
			getLogger().error("Servcie exception return:" + serviceId, e);
			throw new RuntimeException("Servcie exception return:" + serviceId, e);
		} finally {

			// Write debug log
			getLogger().debug("Service output:", jsonOutput);
			// Write application log
			long useTime = System.currentTimeMillis() - startTime;
			getLogger().info("Service take time:", useTime);
			// close session context
			SessionContext.close();
		}
		return chain;
	}

	/**
	 * URL decode
	 * 
	 * @param msg
	 * @param encode
	 * @return
	 */
	protected String decode(String msg, String encode) {
		try {
			msg = URLDecoder.decode(msg, encode);
		} catch (Exception e) {
			getLogger().error("URL decode error:" + msg, e);
		}
		return msg;
	}

}
