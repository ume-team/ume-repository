package org.umeframework.dora.exception;

import org.umeframework.dora.service.ServiceResponse;

/**
 * ExceptionHandler interface declare
 * 
 * @author Yue MA
 * 
 */
public interface ExceptionHandler {
    /**
     * ExceptionHandler function entry
     * 
     * @param serviceResponse
     *            ServiceResponse object
     * @param exception
     *            Exception object
     */
    void handleException(
            ServiceResponse<Object> serviceResponse,
            Throwable exception);
}
