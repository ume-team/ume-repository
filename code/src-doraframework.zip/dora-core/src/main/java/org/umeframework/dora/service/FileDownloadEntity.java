package org.umeframework.dora.service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * FileDownloadObject
 * 
 * @author mayue
 *
 */
public class FileDownloadEntity implements Serializable {

    /**
	 * serial version UID
	 */
	private static final long serialVersionUID = -7830379736319795275L;
	/**
     * contentTypes
     */
    private static final Map<String, String> contentTypes = new HashMap<String, String>();
    static {
        contentTypes.put("json", "application/json");
        contentTypes.put("xml", "application/xml");
        contentTypes.put("octet", "application/octet-stream");
        contentTypes.put("pdf", "application/pdf");
        contentTypes.put("msword", "application/msword");
        contentTypes.put("form", "multipart/form-data");
        contentTypes.put("gif", "image/gif");
        contentTypes.put("jpeg", "image/jpeg");
        contentTypes.put("png", "image/png");
        contentTypes.put("text", "text/plain");
    }
    /**
     * File name with file path
     */
    private String fileName;
    /**
     * File char set for download use 
     */
    private String characterEncoding = "utf-8";
    /**
     * Download content type
     */
    private String contentType = "application/octet-stream";
    /**
     * Download default use file name
     */
    private String downloadName;
    /**
     * File is store as internal resource flag
     */
    private boolean internalResource = false;
    
    /**
     * FileDownloadObject
     * 
     * @param fileName
     * @param internalResource
     */
    public FileDownloadEntity(String fileName, boolean internalResource) {
        init(fileName, internalResource, "utf-8", "application/octet-stream");
    }
    
    /**
     * @param fileName
     * @param internalResource
     * @param characterEncoding
     * @param contentType
     */
    public FileDownloadEntity(String fileName, boolean internalResource, String characterEncoding, String contentType) {
        init(fileName, internalResource, characterEncoding, contentType);
    }

    /**
     * FileDownloadObject
     * 
     * @param fileName
     */
    public FileDownloadEntity(String fileName) {
        init(fileName, false, "utf-8", "application/octet-stream");
    }
    
    /**
     * FileDownloadObject
     * 
     * @param fileName
     * @param characterEncoding
     * @param contentType
     */
    public FileDownloadEntity(String fileName, String characterEncoding, String contentType) {
        init(fileName, false, characterEncoding, contentType);
    }
    
    /**
     * init
     * 
     * @param fileName
     * @param internalResource
     * @param characterEncoding
     * @param contentType
     */
    protected void init(String fileName, boolean internalResource, String characterEncoding, String contentType) {
        if (contentTypes.containsKey(contentType.toLowerCase())) {
            contentType = contentTypes.get(contentType.toLowerCase());
        }

        fileName = fileName.contains("\\")? fileName.replace("\\", "/") : fileName;
        this.fileName = fileName;
        this.downloadName = fileName.contains("/") ? fileName.substring(fileName.lastIndexOf("/") + 1) : fileName;
        this.internalResource =internalResource;
        this.characterEncoding = characterEncoding;
        this.contentType = contentType;
    }

    /**
     * @return the characterEncoding
     */
    public String getCharacterEncoding() {
        return characterEncoding;
    }

    /**
     * @param characterEncoding the characterEncoding to set
     */
    public void setCharacterEncoding(
            String characterEncoding) {
        this.characterEncoding = characterEncoding;
    }

    /**
     * @return the contentType
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * @param contentType the contentType to set
     */
    public void setContentType(
            String contentType) {
        this.contentType = contentType;
    }

    /**
     * @return the downloadName
     */
    public String getDownloadName() {
        return downloadName;
    }

    /**
     * @param downloadName the downloadName to set
     */
    public void setDownloadName(
            String downloadName) {
        this.downloadName = downloadName;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @return the internalResource
     */
    public boolean isInternalResource() {
        return internalResource;
    }

}
