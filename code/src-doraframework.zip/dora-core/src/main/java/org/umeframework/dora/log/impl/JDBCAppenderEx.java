package org.umeframework.dora.log.impl;

import java.sql.SQLException;

/**
 * JDBCAppender
 * 
 * @author mayue
 *
 */
@Deprecated
public class JDBCAppenderEx extends org.apache.log4j.jdbc.JDBCAppender {

    /* (non-Javadoc)
     * @see org.apache.log4j.jdbc.JDBCAppender#execute(java.lang.String)
     */
    @Override
    public void execute(String sql) throws SQLException {
        try {
            super.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

}
