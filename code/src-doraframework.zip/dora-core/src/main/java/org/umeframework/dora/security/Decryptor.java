package org.umeframework.dora.security;

/**
 * Decryptor
 * 
 * @author mmayye
 * 
 *
 */
public interface Decryptor {
	/**
	 * decrypt
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	String decrypt(
            String data) throws Exception;
}
