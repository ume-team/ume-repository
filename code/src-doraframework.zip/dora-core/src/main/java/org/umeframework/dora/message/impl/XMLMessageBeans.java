package org.umeframework.dora.message.impl;

import java.util.ArrayList;
import java.util.List;

/**
 * XMLMessageBeans
 * 
 * @author Yue MA
 */
public class XMLMessageBeans implements java.io.Serializable {

    /**
	 * serial version UID
	 */
	private static final long serialVersionUID = -7000498194891632604L;
	/**
	 * beans
     */
    private List<XMLMessageBean> beans = new ArrayList<XMLMessageBean>();

    /**
     * addBean
     * 
     * @param bean
     */
    public void addBean(
            XMLMessageBean bean) {
        beans.add(bean);
    }

    /**
     * @return the beans
     */
    public List<XMLMessageBean> getBeans() {
        return beans;
    }

    /**
     * @param beans
     *            the beans to set
     */
    public void setBeans(
            List<XMLMessageBean> beans) {
        this.beans = beans;
    }
}
