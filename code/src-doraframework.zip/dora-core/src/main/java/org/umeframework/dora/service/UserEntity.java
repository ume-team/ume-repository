package org.umeframework.dora.service;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * User basic entity.<br>
 *
 * @author Yue MA
 */
public class UserEntity implements Serializable {

    /**
	 * serial version UID
	 */
	private static final long serialVersionUID = -7782561093844234342L;
	/**
     * user identify ID
     */
    private String uid;
    /**
     * internal identify token
     */
    private String token;
    /**
     * login time
     */
    private Timestamp lastTransactionTime;
    /**
     * @return the uid
     */
    public String getUid() {
        return uid;
    }
    /**
     * @param uid the uid to set
     */
    public void setUid(
            String uid) {
        this.uid = uid;
    }
    /**
     * @return the lastTransactionTime
     */
    public Timestamp getLastTransactionTime() {
        return lastTransactionTime;
    }
    /**
     * @param lastTransactionTime the lastTransactionTime to set
     */
    public void setLastTransactionTime(
            Timestamp lastTransactionTime) {
        this.lastTransactionTime = lastTransactionTime;
    }
    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }
    /**
     * @param token the token to set
     */
    public void setToken(
            String token) {
        this.token = token;
    }


}
