package org.umeframework.dora.service.interceptor.impl;

import javax.annotation.Resource;

import org.umeframework.dora.ajax.AjaxRender;
import org.umeframework.dora.service.BaseComponent;
import org.umeframework.dora.service.ServiceResponse;
import org.umeframework.dora.service.interceptor.Interceptor;
import org.umeframework.dora.service.interceptor.InterceptorChain;

/**
 * Service output parameter processor.<br>
 * 
 * @author Yue MA
 * 
 */
public class ServiceOutputInterceptor extends BaseComponent implements Interceptor {

	/**
	 * json data render
	 */
	@Resource(name="ajaxRender")
	private AjaxRender<String> ajaxRender;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.umeframework.dora.web.interceptor.Interceptor#intercept(tora.
	 * fw.web.interceptor.InterceptorChain)
	 */
	@Override
	public void intercept(InterceptorChain chain) throws Exception {
		ServiceResponse<Object> serviceResponse = chain.getServiceResponse();
		String jsonOutput = ajaxRender.render(serviceResponse);
		chain.setJsonOutputData(jsonOutput);

		chain.next();
		// Write debug log
		getLogger().debug("Service Output:", jsonOutput);
	}

	/**
	 * @return the ajaxRender
	 */
	public AjaxRender<String> getAjaxRender() {
		return ajaxRender;
	}

	/**
	 * @param ajaxRender
	 *            the ajaxRender to set
	 */
	public void setAjaxRender(AjaxRender<String> ajaxRender) {
		this.ajaxRender = ajaxRender;
	}

}
