package org.umeframework.dora.validation.format;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * EmptyReplaceValue
 * 
 * @author Yue MA
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface EmptyReplaceValue {
    /**
     * value
     * 
     * @return
     */
    public String value();
}
