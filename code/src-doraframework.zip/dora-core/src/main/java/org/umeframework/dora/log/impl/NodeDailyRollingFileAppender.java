package org.umeframework.dora.log.impl;

import java.io.IOException;

import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.Layout;

/**
 * NodeDailyRollingFileAppender
 * 
 * @author Yue MA
 */
@Deprecated
public class NodeDailyRollingFileAppender extends DailyRollingFileAppender {
    /**
     * NODE_ID
     */
    private static final String NODE_ID = String.valueOf(System.getProperty("nodeid") == null ? "1" : System.getProperty("nodeid"));

    /**
     * NODE_ID_TOKEN
     */
    private static final String NODE_ID_TOKEN = "\\$nodeid\\$";

    /**
     * replaceNodeId
     * 
     * @param fileName
     *            File Name
     * @return String
     */
    public static String replaceNodeId(
            String fileName) {
        return fileName.replaceAll(NODE_ID_TOKEN, NODE_ID);
    }

    /**
     * NodeDailyRollingFileAppender
     */
    public NodeDailyRollingFileAppender() {
        super();
    }

    /**
     * NodeDailyRollingFileAppender
     * 
     * @param layout
     * @param filename
     * @param datePattern
     * @throws IOException
     */
    public NodeDailyRollingFileAppender(
            Layout layout,
            String filename,
            String datePattern) throws IOException {
        super(layout, replaceNodeId(filename), datePattern);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.log4j.FileAppender#getFile()
     */
    @Override
    public synchronized String getFile() {
        return replaceNodeId(super.getFile());
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.log4j.FileAppender#setFile(java.lang.String)
     */
    @Override
    public void setFile(
            String fileName) {
        super.setFile(replaceNodeId(fileName));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.log4j.FileAppender#setFile(java.lang.String, boolean,
     * boolean, int)
     */
    @Override
    public synchronized void setFile(
            String fileName,
            boolean append,
            boolean bufferedIO,
            int bufferSize) throws IOException {
        super.setFile(replaceNodeId(fileName), append, bufferedIO, bufferSize);
    }

}
