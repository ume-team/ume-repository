package org.umeframework.dora.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SessionContext
 *
 * @author Yue MA
 */
public class SessionContext {
    /**
     * session context permit key define
     */
    public static enum Key {
    	RequestCategory, RequestHost, HttpSession, TransactionTime, TransactionStatus, Datasource, SysId, ServiceId, RetryException, AppRootPath, Token, UID
    }

    /**
     * contextHolder
     */
    private static final ThreadLocal<SessionContext> contextHolder = new ThreadLocal<SessionContext>();
    /**
     * block
     */
    private static final byte[] block = new byte[0];

    /**
     * open
     *
     * @return
     */
    public static SessionContext open() {
        SessionContext context = contextHolder.get();
        synchronized (block) {
            if (context == null) {
                context = new SessionContext();
                contextHolder.set(context);
            }
        }
        return context;
    }

    /**
     * close
     */
    public static void close() {
        SessionContext context = contextHolder.get();
        synchronized (block) {
            if (context != null) {
                context.messages.clear();
                context.dataMap.clear();
            }
        }
        contextHolder.set(null);
        contextHolder.remove();
    }

    /**
     * messages
     */
    private List<String> messages;

    /**
     * dataContainer
     */
    private Map<Key, Object> dataMap;

    /**
     * RequestContext
     */
    private SessionContext() {
        dataMap = new HashMap<Key, Object>();
        messages = new ArrayList<String>();
    }

    /**
     * get
     *
     * @param key
     */
    @SuppressWarnings("unchecked")
    public <E> E get(
            Key key) {
        return (E) dataMap.get(key);
    }

    /**
     * set
     *
     * @param key
     * @param obj
     */
    public <E> void set(
            Key key,
            E obj) {
        dataMap.put(key, obj);
    }

    /**
     * remove
     *
     * @param key
     */
    public void remove(
            Key key) {
        dataMap.remove(key);
    }

    /**
     * getMessages
     *
     */
    public List<String> getMessages() {
        return messages;
    }

    /**
     * addMessage
     *
     * @param message
     */
    public void addMessage(
    		String message) {
        messages.add(message);
    }

}
