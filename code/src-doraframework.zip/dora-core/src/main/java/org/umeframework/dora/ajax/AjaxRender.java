package org.umeframework.dora.ajax;

/**
 * json data rending interface.<br>
 * 
 * @author Yue MA
 */
public interface AjaxRender<E> {
    /**
     * Render java object to json text
     * 
     * @param javaObj
     *            - java object
     * @return - json text string
     */
    E render(
            Object javaObj);
}
