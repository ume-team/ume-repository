package org.umeframework.dora.exception;

import org.umeframework.dora.exception.SystemException;

/**
 * TimeoutException
 * 
 * @author Yue MA
 *
 */
public class TimeoutException extends SystemException {

	/**
	 * serial version UID
	 */
	private static final long serialVersionUID = 4809286154167801279L;

	/**
	 * TimeoutException
	 *
	 * @param message
	 * @param parameters
	 */
	public TimeoutException(String message, Object[] parameters) {
		super(message, parameters);
	}
	
	/**
	 * TimeoutException
	 *
	 * @param message
	 */
	public TimeoutException(String message) {
		super(message);
	}

}
