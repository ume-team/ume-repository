package org.umeframework.dora.http;

/**
 * HttpProcessProgress
 * 
 */
public interface HttpProcessProgress {
    /**
     * onProgress
     * 
     * @param progress
     */
    void onProgress(int progress);
}
